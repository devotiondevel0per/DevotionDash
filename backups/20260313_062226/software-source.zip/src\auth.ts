import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import { z } from "zod";
import {
  clearLoginFailures,
  evaluateNetworkAccess,
  getRequestCountry,
  getRequestIp,
  getSecurityPolicy,
  isLoginBlocked,
  recordLoginFailure,
} from "@/lib/security-policy";
import { getUserTwoFactorState, verifyAndConsumeTwoFactorCode } from "@/lib/user-2fa";
import { writeAuditLog } from "@/lib/audit-log";

const loginSchema = z.object({
  login: z.string().min(1),
  password: z.string().min(1),
  otp: z.string().optional(),
});

export const { handlers, auth, signIn, signOut } = NextAuth({
  adapter: PrismaAdapter(prisma),
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login",
  },
  providers: [
    Credentials({
      name: "credentials",
      credentials: {
        login: { label: "Login", type: "text" },
        password: { label: "Password", type: "password" },
        otp: { label: "2-Step Code", type: "text" },
      },
      async authorize(credentials, request) {
        const parsed = loginSchema.safeParse(credentials);
        if (!parsed.success) return null;

        const { login, password, otp } = parsed.data;
        const policy = await getSecurityPolicy();
        const ip = getRequestIp(request.headers);
        const country = getRequestCountry(request.headers);
        const networkCheck = evaluateNetworkAccess(policy, { ip, country });
        if (!networkCheck.allowed) {
          await writeAuditLog({
            action: "LOGIN_BLOCKED_NETWORK",
            module: "administration",
            details: JSON.stringify({ login, ip, country, reason: networkCheck.reason ?? "blocked" }),
            ipAddress: ip,
          });
          return null;
        }

        const rateLimitState = await isLoginBlocked(login, ip);
        if (rateLimitState.blocked) {
          await writeAuditLog({
            action: "LOGIN_BLOCKED_RATE",
            module: "administration",
            details: JSON.stringify({ login, ip, blockedUntil: rateLimitState.blockedUntil }),
            ipAddress: ip,
          });
          return null;
        }

        const user = await prisma.user.findFirst({
          where: {
            OR: [{ login }, { email: login }],
            isActive: true,
          },
        });

        if (!user) {
          await recordLoginFailure(login, ip, policy);
          await writeAuditLog({
            action: "LOGIN_FAILED",
            module: "administration",
            details: JSON.stringify({ login, ip, reason: "user_not_found" }),
            ipAddress: ip,
          });
          return null;
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
          await recordLoginFailure(login, ip, policy);
          await writeAuditLog({
            userId: user.id,
            action: "LOGIN_FAILED",
            module: "administration",
            details: JSON.stringify({ login, ip, reason: "password_mismatch" }),
            ipAddress: ip,
          });
          return null;
        }

        const twoFactorState = await getUserTwoFactorState(user.id);
        const requiresTwoFactor = Boolean(twoFactorState?.enabled) || (policy.enforce2FAForAdmins && user.isAdmin);
        if (requiresTwoFactor) {
          if (!twoFactorState?.enabled) {
            await recordLoginFailure(login, ip, policy);
            await writeAuditLog({
              userId: user.id,
              action: "LOGIN_2FA_REQUIRED",
              module: "administration",
              details: JSON.stringify({ login, ip, reason: "2fa_not_enabled_for_required_user" }),
              ipAddress: ip,
            });
            return null;
          }
          if (!otp || !(await verifyAndConsumeTwoFactorCode(user.id, otp))) {
            await recordLoginFailure(login, ip, policy);
            await writeAuditLog({
              userId: user.id,
              action: "LOGIN_2FA_FAILED",
              module: "administration",
              details: JSON.stringify({ login, ip }),
              ipAddress: ip,
            });
            return null;
          }
        }

        await clearLoginFailures(login, ip);

        await prisma.user.update({
          where: { id: user.id },
          data: { lastActivity: new Date() },
        });

        await writeAuditLog({
          userId: user.id,
          action: "LOGIN_SUCCESS",
          module: "administration",
          details: JSON.stringify({ login, ip, country }),
          ipAddress: ip,
        });

        return {
          id: user.id,
          email: user.email,
          name: user.fullname || `${user.name} ${user.surname}`.trim(),
          login: user.login,
          isAdmin: user.isAdmin,
          photoUrl: user.photoUrl,
          department: user.department,
          position: user.position,
          twoFactorEnabled: Boolean(twoFactorState?.enabled),
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        const authUser = user as {
          id: string;
          login?: string;
          isAdmin?: boolean;
          photoUrl?: string | null;
          department?: string;
          position?: string;
          twoFactorEnabled?: boolean;
        };

        token.id = user.id;
        token.login = authUser.login;
        token.isAdmin = authUser.isAdmin;
        token.photoUrl = authUser.photoUrl;
        token.department = authUser.department;
        token.position = authUser.position;
        token.twoFactorEnabled = authUser.twoFactorEnabled;
        token.authAt = Date.now();
      }
      return token;
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string;
        session.user.login = token.login;
        session.user.isAdmin = token.isAdmin;
        session.user.photoUrl = token.photoUrl;
        session.user.department = token.department;
        session.user.position = token.position;
        session.user.twoFactorEnabled = token.twoFactorEnabled;
        session.user.authAt = token.authAt;
      }
      return session;
    },
  },
});

﻿"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Search,
  Mail,
  Phone,
  MessageSquare,
  Users,
  Cake,
  Clock,
  Copy,
  Check,
  Loader2,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type TeamUser = {
  id: string;
  login: string;
  email: string;
  name: string;
  surname: string;
  fullname: string;
  position: string;
  department: string;
  phoneWork: string;
  phoneMobile: string;
  photoUrl: string | null;
  workState: number | null;
  isActive: boolean;
  lastActivity: string | null;
  dateBirthday: string | null;
  createdAt: string;
};

type BirthdayItem = {
  member: TeamUser;
  isToday: boolean;
  upcoming: boolean;
  dateLabel: string;
  daysAway: number;
};

const AVATAR_COLORS = [
  "bg-primary/10 text-primary",
  "bg-purple-100 text-purple-700",
  "bg-green-100 text-green-700",
  "bg-orange-100 text-orange-700",
  "bg-pink-100 text-pink-700",
  "bg-teal-100 text-teal-700",
  "bg-indigo-100 text-indigo-700",
  "bg-yellow-100 text-yellow-700",
];

const WORK_DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const DEFAULT_SCHEDULE = [true, true, true, true, true, false, false];

function initialsOf(user: TeamUser): string {
  const full = user.fullname || `${user.name} ${user.surname}`.trim() || user.login;
  return full
    .split(" ")
    .filter(Boolean)
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function fullNameOf(user: TeamUser): string {
  return user.fullname || `${user.name} ${user.surname}`.trim() || user.login;
}

function isOnlineUser(user: TeamUser): boolean {
  if (!user.isActive || !user.lastActivity) return false;
  const diff = Date.now() - new Date(user.lastActivity).getTime();
  return diff < 5 * 60 * 1000;
}

function hasBirthdaySoon(user: TeamUser, withinDays = 30): BirthdayItem | null {
  if (!user.dateBirthday) return null;
  const original = new Date(user.dateBirthday);
  if (Number.isNaN(original.getTime())) return null;

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  let next = new Date(now.getFullYear(), original.getMonth(), original.getDate());
  if (next < today) {
    next = new Date(now.getFullYear() + 1, original.getMonth(), original.getDate());
  }

  const daysAway = Math.floor((next.getTime() - today.getTime()) / 86400000);
  const isToday = daysAway === 0;
  const upcoming = daysAway >= 0 && daysAway <= withinDays;
  const dateLabel = next.toLocaleDateString([], { month: "long", day: "numeric" });

  return {
    member: user,
    isToday,
    upcoming,
    dateLabel,
    daysAway,
  };
}

function CopyButton({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy(e: React.MouseEvent) {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      toast.success(`${label} copied`);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error(`Unable to copy ${label}`);
    }
  }

  return (
    <button
      onClick={(e) => void handleCopy(e)}
      className="shrink-0 rounded p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
      title={`Copy ${label}`}
    >
      {copied ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
    </button>
  );
}

function EmployeeCard({
  employee,
  colorClass,
  creatingChat,
  onStartChat,
}: {
  employee: TeamUser;
  colorClass: string;
  creatingChat: boolean;
  onStartChat: (user: TeamUser) => void;
}) {
  const fullName = fullNameOf(employee);
  const online = isOnlineUser(employee);
  const phone = employee.phoneMobile || employee.phoneWork || "";
  const birthday = hasBirthdaySoon(employee, 30);
  const hasBirthdayFlag = Boolean(birthday?.upcoming);

  return (
    <Card className="group transition-all duration-150 hover:shadow-md">
      <CardContent className="p-5">
        <div className="mb-3 flex items-start gap-3">
          <div className="relative shrink-0">
            <Avatar className="h-14 w-14">
              <AvatarFallback className={cn("text-lg font-semibold", colorClass)}>{initialsOf(employee)}</AvatarFallback>
            </Avatar>
            <span
              className={cn(
                "absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full border-2 border-white",
                online ? "bg-green-500" : "bg-gray-300"
              )}
              title={online ? "Online" : "Offline"}
            />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5">
              <h3 className="truncate text-sm font-semibold text-gray-900">{fullName}</h3>
              {hasBirthdayFlag ? (
                <span title="Birthday in next 30 days">
                  <Cake className="h-3.5 w-3.5 text-amber-500" />
                </span>
              ) : null}
            </div>
            <p className="mt-0.5 truncate text-xs text-gray-500">{employee.position || "No position"}</p>
            <Badge variant="secondary" className="mt-1.5 max-w-full truncate bg-gray-100 text-xs text-gray-600">
              {employee.department || "No department"}
            </Badge>
          </div>
        </div>

        <div className="space-y-1.5 border-t pt-3">
          <div className="flex items-center gap-1.5">
            <Mail className="h-3.5 w-3.5 shrink-0 text-gray-400" />
            <span className="flex-1 truncate text-xs text-gray-600">{employee.email}</span>
            {employee.email ? <CopyButton value={employee.email} label="email" /> : null}
          </div>
          <div className="flex items-center gap-1.5">
            <Phone className="h-3.5 w-3.5 shrink-0 text-gray-400" />
            <span className="flex-1 text-xs text-gray-600">{phone || "No phone"}</span>
            {phone ? <CopyButton value={phone} label="phone" /> : null}
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="h-7 flex-1 text-xs"
            onClick={() => {
              if (!employee.email) {
                toast.error("No email address found");
                return;
              }
              window.location.href = `mailto:${employee.email}`;
            }}
          >
            <Mail className="mr-1 h-3 w-3" />
            Email
          </Button>

          <Button
            variant="outline"
            size="sm"
            className="h-7 flex-1 text-xs"
            disabled={creatingChat}
            onClick={() => onStartChat(employee)}
          >
            {creatingChat ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <MessageSquare className="mr-1 h-3 w-3" />}
            Chat
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function TeamPage() {
  const [members, setMembers] = useState<TeamUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [deptFilter, setDeptFilter] = useState("all");
  const [creatingChatUserId, setCreatingChatUserId] = useState<string | null>(null);

  const loadMembers = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/team/users?limit=500", { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to load team users");
      const data = (await response.json()) as TeamUser[];
      setMembers(Array.isArray(data) ? data : []);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Failed to load team");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadMembers();
  }, [loadMembers]);

  async function startChatWith(user: TeamUser) {
    setCreatingChatUserId(user.id);
    try {
      const response = await fetch("/api/chat/dialogs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: `Direct: ${fullNameOf(user)}`,
          memberIds: [user.id],
        }),
      });

      const data = (await response.json()) as { error?: string };
      if (!response.ok) {
        toast.error(data.error ?? "Unable to open chat");
        return;
      }

      window.location.href = "/chat";
    } catch {
      toast.error("Unable to open chat");
    } finally {
      setCreatingChatUserId(null);
    }
  }

  const departments = useMemo(() => {
    const depts = new Set<string>();
    for (const member of members) {
      if (member.department) depts.add(member.department);
    }
    return Array.from(depts).sort();
  }, [members]);

  const filtered = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return members.filter((member) => {
      const matchesDept = deptFilter === "all" || member.department === deptFilter;
      const matchesSearch =
        !query ||
        fullNameOf(member).toLowerCase().includes(query) ||
        (member.position ?? "").toLowerCase().includes(query) ||
        (member.department ?? "").toLowerCase().includes(query) ||
        (member.email ?? "").toLowerCase().includes(query);
      return matchesDept && matchesSearch;
    });
  }, [members, searchQuery, deptFilter]);

  const birthdayMembers = useMemo(() => {
    return members
      .map((member) => hasBirthdaySoon(member, 30))
      .filter((item): item is BirthdayItem => Boolean(item && item.upcoming))
      .sort((a, b) => a.daysAway - b.daysAway);
  }, [members]);

  const byDepartment = useMemo(() => {
    const map = new Map<string, TeamUser[]>();
    for (const member of members) {
      const department = member.department || "No Department";
      const existing = map.get(department) ?? [];
      existing.push(member);
      map.set(department, existing);
    }
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [members]);

  return (
    <div className="flex h-full flex-col">
      <div className="border-b bg-white px-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">Team</h1>
            <p className="mt-0.5 text-sm text-gray-500">
              {members.length} member{members.length !== 1 ? "s" : ""}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => void loadMembers()}>
              <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
              Refresh
            </Button>

            <Select value={deptFilter} onValueChange={(value) => setDeptFilter(value ?? "all")}>
              <SelectTrigger className="h-8 w-44 text-sm">
                <SelectValue placeholder="All departments" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All departments</SelectItem>
                {departments.map((department) => (
                  <SelectItem key={department} value={department}>
                    {department}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="relative w-64">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Search team members..."
                className="h-8 pl-8 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="list" className="flex h-full flex-col">
          <div className="border-b bg-white px-6">
            <TabsList className="h-10 gap-0 rounded-none border-none bg-transparent p-0">
              {[
                { value: "list", label: "List", Icon: Users },
                { value: "structure", label: "Structure", Icon: Users },
                { value: "birthdays", label: "Birthdays", Icon: Cake },
                { value: "working-time", label: "Working Time", Icon: Clock },
              ].map(({ value, label, Icon }) => (
                <TabsTrigger
                  key={value}
                  value={value}
                  className="h-10 rounded-none border-b-2 border-transparent px-4 text-sm text-gray-500 data-[state=active]:border-[#FE0000] data-[state=active]:bg-transparent data-[state=active]:text-[#FE0000] data-[state=active]:shadow-none"
                >
                  <Icon className="mr-1.5 h-4 w-4" />
                  {label}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value="list" className="mt-0 flex-1 overflow-y-auto bg-gray-50 p-6">
            {loading ? (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {Array.from({ length: 8 }).map((_, idx) => (
                  <Skeleton key={idx} className="h-52 rounded-xl" />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="py-20 text-center text-gray-400">
                <Users className="mx-auto mb-3 h-12 w-12 opacity-25" />
                <p className="text-sm font-medium">No team members found</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {filtered.map((member, idx) => (
                  <EmployeeCard
                    key={member.id}
                    employee={member}
                    colorClass={AVATAR_COLORS[idx % AVATAR_COLORS.length]}
                    creatingChat={creatingChatUserId === member.id}
                    onStartChat={startChatWith}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="structure" className="mt-0 flex-1 overflow-y-auto bg-gray-50 p-6">
            {loading ? (
              <div className="space-y-4">
                <Skeleton className="h-8 w-40" />
                <Skeleton className="h-28 w-full" />
                <Skeleton className="h-8 w-40" />
                <Skeleton className="h-28 w-full" />
              </div>
            ) : (
              <div className="space-y-6">
                {byDepartment.map(([department, departmentMembers]) => (
                  <div key={department}>
                    <div className="mb-3 flex items-center gap-2">
                      <div className="h-5 w-1 rounded-full" style={{ backgroundColor: "#FE0000" }} />
                      <h3 className="text-sm font-semibold text-gray-800">{department}</h3>
                      <Badge variant="secondary" className="bg-gray-100 text-xs text-gray-500">
                        {departmentMembers.length}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 gap-3 pl-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                      {departmentMembers.map((member, idx) => {
                        const online = isOnlineUser(member);
                        return (
                          <div
                            key={member.id}
                            className="flex items-center gap-3 rounded-lg border bg-white p-3 transition-shadow hover:shadow-sm"
                          >
                            <div className="relative shrink-0">
                              <Avatar className="h-9 w-9">
                                <AvatarFallback
                                  className={cn("text-sm font-semibold", AVATAR_COLORS[idx % AVATAR_COLORS.length])}
                                >
                                  {initialsOf(member)}
                                </AvatarFallback>
                              </Avatar>
                              <span
                                className={cn(
                                  "absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-white",
                                  online ? "bg-green-500" : "bg-gray-300"
                                )}
                              />
                            </div>
                            <div className="min-w-0">
                              <p className="truncate text-sm font-medium text-gray-900">{fullNameOf(member)}</p>
                              <p className="truncate text-xs text-gray-500">{member.position || "No position"}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}

                {byDepartment.length === 0 ? (
                  <div className="py-20 text-center text-gray-400">
                    <Users className="mx-auto mb-3 h-12 w-12 opacity-25" />
                    <p className="text-sm">No team structure available</p>
                  </div>
                ) : null}
              </div>
            )}
          </TabsContent>

          <TabsContent value="birthdays" className="mt-0 flex-1 overflow-y-auto bg-gray-50 p-6">
            {loading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, idx) => (
                  <Skeleton key={idx} className="h-16 w-full" />
                ))}
              </div>
            ) : birthdayMembers.length === 0 ? (
              <div className="py-20 text-center text-gray-400">
                <Cake className="mx-auto mb-3 h-12 w-12 opacity-25" />
                <p className="text-sm">No upcoming birthdays in the next 30 days</p>
              </div>
            ) : (
              <div className="max-w-2xl space-y-3">
                <p className="mb-4 text-xs text-gray-400">Upcoming birthdays in the next 30 days</p>
                {birthdayMembers.map(({ member, isToday, dateLabel }, idx) => (
                  <div
                    key={member.id}
                    className={cn(
                      "flex items-center gap-4 rounded-xl border bg-white p-4",
                      isToday && "border-[#FE0000]/30 bg-red-50/30"
                    )}
                  >
                    <Avatar className="h-11 w-11 shrink-0">
                      <AvatarFallback className={cn("text-base font-semibold", AVATAR_COLORS[idx % AVATAR_COLORS.length])}>
                        {initialsOf(member)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-gray-900">{fullNameOf(member)}</p>
                      <p className="text-xs text-gray-500">{member.position || "No position"}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-sm font-medium text-gray-700">{dateLabel}</p>
                      {isToday ? (
                        <Badge variant="secondary" className="mt-1 text-xs" style={{ backgroundColor: "#FFF0F0", color: "#FE0000" }}>
                          Today
                        </Badge>
                      ) : null}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="working-time" className="mt-0 flex-1 overflow-y-auto bg-gray-50 p-6">
            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 6 }).map((_, idx) => (
                  <Skeleton key={idx} className="h-10 w-full" />
                ))}
              </div>
            ) : (
              <div className="max-w-4xl overflow-hidden rounded-xl border bg-white">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 hover:bg-gray-50">
                      <TableHead className="w-52 pl-6">Employee</TableHead>
                      {WORK_DAYS.map((day) => (
                        <TableHead key={day} className="w-16 text-center">
                          {day}
                        </TableHead>
                      ))}
                      <TableHead className="w-24 pr-6 text-center">Hours/day</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {members.slice(0, 50).map((member) => {
                      const schedule = member.workState === 0 ? [false, false, false, false, false, false, false] : DEFAULT_SCHEDULE;
                      const hoursPerDay = member.workState === 0 ? 0 : 8;

                      return (
                        <TableRow key={member.id} className="hover:bg-gray-50/50">
                          <TableCell className="pl-6">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-7 w-7">
                                <AvatarFallback className="bg-gray-100 text-xs text-gray-600">{initialsOf(member)}</AvatarFallback>
                              </Avatar>
                              <span className="max-w-32 truncate text-sm font-medium text-gray-800">{fullNameOf(member)}</span>
                            </div>
                          </TableCell>

                          {schedule.map((works, dayIndex) => (
                            <TableCell key={dayIndex} className="text-center">
                              {works ? (
                                <Check className="mx-auto h-4 w-4 text-green-500" />
                              ) : (
                                <span className="text-xs text-gray-300">-</span>
                              )}
                            </TableCell>
                          ))}

                          <TableCell className="pr-6 text-center text-sm text-gray-600">{hoursPerDay}h</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>

                {members.length === 0 ? (
                  <div className="py-12 text-center text-gray-400">
                    <Clock className="mx-auto mb-3 h-10 w-10 opacity-25" />
                    <p className="text-sm">No team members</p>
                  </div>
                ) : null}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

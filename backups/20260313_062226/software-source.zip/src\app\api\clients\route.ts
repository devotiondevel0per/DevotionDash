import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireModuleAccess } from "@/lib/api-access";

export async function GET(req: NextRequest) {
  const accessResult = await requireModuleAccess("clients", "read");
  if (!accessResult.ok) return accessResult.response;

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const type = searchParams.get("type");
    const rating = searchParams.get("rating");
    const managerId = searchParams.get("managerId");
    const search = searchParams.get("search");
    const sort = searchParams.get("sort");
    const limit = Math.min(
      Math.max(parseInt(searchParams.get("limit") ?? "80", 10), 1),
      500
    );

    const where: Record<string, unknown> = {};

    if (status && status !== "all") where.status = status;
    if (type && type !== "all") where.type = type;
    if (rating && rating !== "all") where.rating = rating;
    if (managerId && managerId !== "all") {
      where.managerId =
        managerId === "me" ? accessResult.ctx.userId : managerId;
    }
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { email: { contains: search } },
        { website: { contains: search } },
        { city: { contains: search } },
        { country: { contains: search } },
        { industry: { contains: search } },
        { leadSource: { contains: search } },
        { comment: { contains: search } },
      ];
    }

    const orderBy =
      sort === "name"
        ? [{ name: "asc" as const }]
        : sort === "created"
          ? [{ createdAt: "desc" as const }]
          : sort === "rating"
            ? [{ rating: "asc" as const }, { updatedAt: "desc" as const }]
            : [{ updatedAt: "desc" as const }];

    const organizations = await prisma.organization.findMany({
      where,
      take: limit,
      orderBy,
      include: {
        manager: { select: { id: true, name: true, fullname: true } },
        sla: { select: { id: true, name: true, hoursLimit: true } },
        _count: {
          select: {
            contacts: true,
            emails: true,
            chatDialogs: true,
            serviceDeskRequests: true,
            historyEntries: true,
          },
        },
      },
    });

    return NextResponse.json(organizations);
  } catch (error) {
    console.error("[GET /api/clients]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const accessResult = await requireModuleAccess("clients", "write");
  if (!accessResult.ok) return accessResult.response;

  try {
    const body = await req.json();
    const {
      name,
      type,
      status,
      rating,
      industry,
      leadSource,
      managerId,
      email,
      website,
      phone,
      fax,
      country,
      city,
      address,
      comment,
      slaId,
    } = body as {
      name: string;
      type?: string;
      status?: string;
      rating?: string;
      industry?: string;
      leadSource?: string;
      managerId?: string | null;
      email?: string;
      website?: string;
      phone?: string;
      fax?: string;
      country?: string;
      city?: string;
      address?: string;
      comment?: string;
      slaId?: string | null;
    };

    if (!name || typeof name !== "string" || name.trim() === "") {
      return NextResponse.json({ error: "name is required" }, { status: 400 });
    }

    if (managerId) {
      const manager = await prisma.user.findUnique({
        where: { id: managerId },
        select: { id: true },
      });
      if (!manager) {
        return NextResponse.json({ error: "Invalid managerId" }, { status: 400 });
      }
    }
    if (slaId) {
      const sla = await prisma.sLA.findUnique({
        where: { id: slaId },
        select: { id: true },
      });
      if (!sla) {
        return NextResponse.json({ error: "Invalid slaId" }, { status: 400 });
      }
    }

    const organization = await prisma.$transaction(async (tx) => {
      const org = await tx.organization.create({
        data: {
          name: name.trim(),
          type: type ?? "potential",
          status: status ?? "open",
          rating: rating ?? "weak",
          industry,
          leadSource,
          managerId: managerId ?? null,
          email,
          website,
          phone,
          fax,
          country,
          city,
          address,
          comment,
          slaId: slaId ?? null,
        },
        include: {
          manager: { select: { id: true, name: true, fullname: true } },
          sla: { select: { id: true, name: true, hoursLimit: true } },
          _count: {
            select: {
              contacts: true,
              emails: true,
              chatDialogs: true,
              serviceDeskRequests: true,
              historyEntries: true,
            },
          },
        },
      });

      await tx.orgHistory.create({
        data: {
          organizationId: org.id,
          userId: accessResult.ctx.userId,
          content: "Organization created",
          isSystem: true,
        },
      });

      return org;
    });

    return NextResponse.json(organization, { status: 201 });
  } catch (error) {
    console.error("[POST /api/clients]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

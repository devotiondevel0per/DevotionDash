import { moduleIds, type ModuleId, type RolePermissionConfig } from "@/lib/permissions";

export const MODULE_TOGGLES_KEY = "system.modules.enabled";
export const USER_PERMISSION_OVERRIDE_PREFIX = "permissions.userOverride.";

const PROTECTED_ALWAYS_ENABLED: ModuleId[] = ["home", "search", "administration"];

export function getDefaultEnabledModules(): ModuleId[] {
  // Keep finance modules hidden by default until explicitly enabled.
  return moduleIds.filter((id) => !["products", "accounting", "ebank"].includes(id));
}

export function normalizeEnabledModules(input: unknown): ModuleId[] {
  const source = Array.isArray(input) ? input : [];
  const set = new Set<ModuleId>();

  for (const value of source) {
    if (typeof value !== "string") continue;
    if (moduleIds.includes(value as ModuleId)) set.add(value as ModuleId);
  }

  for (const moduleId of PROTECTED_ALWAYS_ENABLED) {
    set.add(moduleId);
  }

  return moduleIds.filter((id) => set.has(id));
}

export function parseEnabledModulesSetting(raw: string | null | undefined): ModuleId[] {
  if (!raw?.trim()) return getDefaultEnabledModules();
  try {
    const parsed = JSON.parse(raw);
    return normalizeEnabledModules(parsed);
  } catch {
    return getDefaultEnabledModules();
  }
}

export function parseRolePermissionConfig(input: unknown): RolePermissionConfig | null {
  if (!input || typeof input !== "object") return null;
  const source = input as Record<string, unknown>;
  const config: RolePermissionConfig = {};

  for (const moduleId of moduleIds) {
    const actions = source[moduleId];
    if (!Array.isArray(actions)) continue;

    const filtered = actions.filter(
      (action): action is "read" | "write" | "manage" =>
        action === "read" || action === "write" || action === "manage"
    );
    if (filtered.length > 0) {
      config[moduleId] = filtered;
    }
  }

  return Object.keys(config).length > 0 ? config : null;
}

export function parseUserPermissionOverrideSetting(raw: string | null | undefined): RolePermissionConfig | null {
  if (!raw?.trim()) return null;
  try {
    const parsed = JSON.parse(raw) as { grants?: unknown };
    return parseRolePermissionConfig(parsed.grants);
  } catch {
    return null;
  }
}

export function toUserPermissionOverrideSetting(grants: RolePermissionConfig | null) {
  return JSON.stringify({
    grants: grants ?? {},
  });
}


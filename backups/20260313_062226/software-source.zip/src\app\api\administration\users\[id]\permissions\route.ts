import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireModuleAccess } from "@/lib/api-access";
import {
  USER_PERMISSION_OVERRIDE_PREFIX,
  parseRolePermissionConfig,
  parseUserPermissionOverrideSetting,
  toUserPermissionOverrideSetting,
} from "@/lib/admin-config";
import { writeAuditLog, getClientIpAddress } from "@/lib/audit-log";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: RouteContext) {
  const accessResult = await requireModuleAccess("administration", "read");
  if (!accessResult.ok) return accessResult.response;

  try {
    const { id } = await params;
    const user = await prisma.user.findUnique({
      where: { id },
      select: { id: true, fullname: true, name: true, surname: true, email: true },
    });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    const key = `${USER_PERMISSION_OVERRIDE_PREFIX}${id}`;
    const setting = await prisma.systemSetting.findUnique({
      where: { key },
      select: { value: true },
    });
    const grants = parseUserPermissionOverrideSetting(setting?.value);

    return NextResponse.json({
      user: {
        id: user.id,
        fullname: user.fullname || `${user.name} ${user.surname}`.trim(),
        email: user.email,
      },
      grants: grants ?? {},
    });
  } catch (error) {
    console.error("[GET /api/administration/users/[id]/permissions]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: RouteContext) {
  const accessResult = await requireModuleAccess("administration", "manage");
  if (!accessResult.ok) return accessResult.response;

  try {
    const { id } = await params;
    const body = (await req.json()) as { grants?: unknown };
    const grants = parseRolePermissionConfig(body.grants);
    const key = `${USER_PERMISSION_OVERRIDE_PREFIX}${id}`;

    const user = await prisma.user.findUnique({ where: { id }, select: { id: true } });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    if (!grants) {
      await prisma.systemSetting.deleteMany({ where: { key } });
    } else {
      await prisma.systemSetting.upsert({
        where: { key },
        create: { key, value: toUserPermissionOverrideSetting(grants) },
        update: { value: toUserPermissionOverrideSetting(grants) },
      });
    }

    await writeAuditLog({
      userId: accessResult.ctx.userId,
      action: "USER_PERMISSION_OVERRIDE_UPDATED",
      module: "administration",
      targetId: id,
      details: JSON.stringify({ grants: grants ?? {} }),
      ipAddress: getClientIpAddress(req),
    });

    return NextResponse.json({ success: true, grants: grants ?? {} });
  } catch (error) {
    console.error("[PUT /api/administration/users/[id]/permissions]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}


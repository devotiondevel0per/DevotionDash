import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();
const dayMs = 24 * 60 * 60 * 1000;

function d(days: number, hour = 9, minute = 0) {
  const t = new Date(Date.now() + days * dayMs);
  t.setHours(hour, minute, 0, 0);
  return t;
}

function rolePermissions(permissions: Record<string, Array<"read" | "write" | "manage">>) {
  return JSON.stringify({ permissions });
}

async function main() {
  console.log("Seeding test data...");
  const password = await bcrypt.hash("admin123", 12);

  const users = [
    ["admin", "admin@teamwox.local", "Admin", "User", "System Administrator", "IT", true],
    ["john.doe", "john@teamwox.local", "John", "Doe", "Sales Manager", "Sales", false],
    ["jane.smith", "jane@teamwox.local", "Jane", "Smith", "Senior Developer", "IT", false],
    ["mohit.kumar", "mohit@teamwox.local", "Mohit", "Kumar", "Support Engineer", "Support", false],
    ["fatima.noor", "fatima@teamwox.local", "Fatima", "Noor", "Finance Controller", "Finance", false],
    ["liam.chen", "liam@teamwox.local", "Liam", "Chen", "HR Specialist", "People", false],
    ["sara.khan", "sara@teamwox.local", "Sara", "Khan", "Project Manager", "Operations", false],
  ] as const;

  const userIds = new Map<string, string>();
  for (const [login, email, name, surname, position, department, isAdmin] of users) {
    const user = await prisma.user.upsert({
      where: { login },
      update: {
        email,
        password,
        name,
        surname,
        fullname: `${name} ${surname}`,
        position,
        department,
        isAdmin,
        isActive: true,
      },
      create: {
        login,
        email,
        password,
        name,
        surname,
        fullname: `${name} ${surname}`,
        position,
        department,
        isAdmin,
        isActive: true,
      },
      select: { id: true },
    });
    userIds.set(login, user.id);
  }
  const uid = (login: string) => {
    const id = userIds.get(login);
    if (!id) throw new Error(`Missing user ${login}`);
    return id;
  };

  const roles = [
    ["seed-role-viewer", "Viewer", "#3B4A61", rolePermissions({ home: ["read"], search: ["read"], tasks: ["read"], projects: ["read"], documents: ["read"], email: ["read"], board: ["read"], clients: ["read"], contacts: ["read"], team: ["read"], calendar: ["read"], chat: ["read"], servicedesk: ["read"], products: ["read"], accounting: ["read"], ebank: ["read"], telephony: ["read"] })],
    ["seed-role-employee", "Employee", "#437388", rolePermissions({ home: ["read"], search: ["read"], tasks: ["read", "write"], projects: ["read", "write"], documents: ["read", "write"], email: ["read", "write"], board: ["read", "write"], calendar: ["read", "write"], chat: ["read", "write"], servicedesk: ["read", "write"] })],
    ["seed-role-crm", "CRM Manager", "#5EAD63", rolePermissions({ home: ["read"], search: ["read"], clients: ["read", "write", "manage"], contacts: ["read", "write", "manage"], servicedesk: ["read", "write", "manage"], email: ["read", "write"], chat: ["read", "write"] })],
    ["seed-role-finance", "Finance Manager", "#818B4B", rolePermissions({ home: ["read"], search: ["read"], products: ["read", "write", "manage"], accounting: ["read", "write", "manage"], ebank: ["read", "write", "manage"], documents: ["read", "write"] })],
    ["seed-role-it", "IT Admin", "#D15600", rolePermissions({ home: ["read"], search: ["read"], administration: ["read", "write", "manage"], telephony: ["read", "write", "manage"], team: ["read", "write"], board: ["read", "write", "manage"] })],
  ] as const;
  for (const [id, name, color, description] of roles) {
    await prisma.group.upsert({ where: { id }, update: { name, color, description }, create: { id, name, color, description } });
  }
  const memberships = [
    ["seed-role-it", "admin", "owner"],
    ["seed-role-employee", "john.doe", "member"],
    ["seed-role-crm", "john.doe", "lead"],
    ["seed-role-employee", "jane.smith", "member"],
    ["seed-role-employee", "mohit.kumar", "member"],
    ["seed-role-finance", "fatima.noor", "lead"],
    ["seed-role-viewer", "liam.chen", "member"],
    ["seed-role-employee", "sara.khan", "manager"],
    ["seed-role-crm", "sara.khan", "manager"],
  ] as const;
  for (const [groupId, login, role] of memberships) {
    await prisma.groupMember.upsert({
      where: { groupId_userId: { groupId, userId: uid(login) } },
      update: { role },
      create: { groupId, userId: uid(login), role },
    });
  }

  await prisma.department.upsert({ where: { id: "seed-dept-it" }, update: { name: "IT", managerId: uid("jane.smith") }, create: { id: "seed-dept-it", name: "IT", managerId: uid("jane.smith") } });
  await prisma.department.upsert({ where: { id: "seed-dept-sales" }, update: { name: "Sales", managerId: uid("john.doe") }, create: { id: "seed-dept-sales", name: "Sales", managerId: uid("john.doe") } });
  for (const [login] of users) {
    await prisma.workSchedule.upsert({ where: { userId: uid(login) }, update: {}, create: { userId: uid(login) } });
  }

  await prisma.organization.upsert({
    where: { id: "seed-org-acme" },
    update: { name: "Acme Logistics LLC", type: "client", status: "open", rating: "good", managerId: uid("john.doe"), city: "Dubai", country: "UAE", email: "ops@acme.example", phone: "+97142201000", comment: "Strategic account." },
    create: { id: "seed-org-acme", name: "Acme Logistics LLC", type: "client", status: "open", rating: "good", managerId: uid("john.doe"), city: "Dubai", country: "UAE", email: "ops@acme.example", phone: "+97142201000", comment: "Strategic account." },
  });
  await prisma.organization.upsert({
    where: { id: "seed-org-orbit" },
    update: { name: "Orbit Retail FZE", type: "potential", status: "open", rating: "hot", managerId: uid("sara.khan"), city: "Dubai", country: "UAE", email: "ops@orbit.example", phone: "+97142201100", comment: "High priority lead." },
    create: { id: "seed-org-orbit", name: "Orbit Retail FZE", type: "potential", status: "open", rating: "hot", managerId: uid("sara.khan"), city: "Dubai", country: "UAE", email: "ops@orbit.example", phone: "+97142201100", comment: "High priority lead." },
  });
  await prisma.contact.upsert({
    where: { id: "seed-contact-1" },
    update: { organizationId: "seed-org-acme", createdById: uid("john.doe"), firstName: "Rami", lastName: "Haddad", email: "rami@acme.example", phone: "+97142201001", position: "Operations Director" },
    create: { id: "seed-contact-1", organizationId: "seed-org-acme", createdById: uid("john.doe"), firstName: "Rami", lastName: "Haddad", email: "rami@acme.example", phone: "+97142201001", position: "Operations Director" },
  });
  await prisma.orgHistory.upsert({
    where: { id: "seed-org-history-1" },
    update: { organizationId: "seed-org-acme", userId: uid("sara.khan"), content: "Discovery workshop completed.", isSystem: false, createdAt: d(-4, 14, 0) },
    create: { id: "seed-org-history-1", organizationId: "seed-org-acme", userId: uid("sara.khan"), content: "Discovery workshop completed.", isSystem: false, createdAt: d(-4, 14, 0) },
  });

  await prisma.calendar.upsert({
    where: { id: "seed-cal-company" },
    update: { name: "Company Calendar", type: "shared", color: "#437388", ownerId: uid("admin") },
    create: { id: "seed-cal-company", name: "Company Calendar", type: "shared", color: "#437388", ownerId: uid("admin") },
  });
  await prisma.calendarMember.upsert({ where: { calendarId_userId: { calendarId: "seed-cal-company", userId: uid("admin") } }, update: { canEdit: true }, create: { calendarId: "seed-cal-company", userId: uid("admin"), canEdit: true } });
  await prisma.calendarMember.upsert({ where: { calendarId_userId: { calendarId: "seed-cal-company", userId: uid("john.doe") } }, update: { canEdit: false }, create: { calendarId: "seed-cal-company", userId: uid("john.doe"), canEdit: false } });
  await prisma.calendarEvent.upsert({
    where: { id: "seed-cal-event-1" },
    update: { calendarId: "seed-cal-company", creatorId: uid("admin"), title: "Daily Standup", startDate: d(0, 9, 30), endDate: d(0, 10, 0), allDay: false },
    create: { id: "seed-cal-event-1", calendarId: "seed-cal-company", creatorId: uid("admin"), title: "Daily Standup", startDate: d(0, 9, 30), endDate: d(0, 10, 0), allDay: false },
  });

  await prisma.task.upsert({
    where: { id: "seed-task-1" },
    update: { title: "Finalize rollout plan", description: "Confirm milestones and owners.", creatorId: uid("sara.khan"), status: "opened", priority: "high", dueDate: d(3, 17, 0) },
    create: { id: "seed-task-1", title: "Finalize rollout plan", description: "Confirm milestones and owners.", creatorId: uid("sara.khan"), status: "opened", priority: "high", dueDate: d(3, 17, 0) },
  });
  await prisma.taskAssignee.upsert({ where: { taskId_userId: { taskId: "seed-task-1", userId: uid("jane.smith") } }, update: {}, create: { taskId: "seed-task-1", userId: uid("jane.smith") } });
  await prisma.taskComment.upsert({ where: { id: "seed-task-comment-1" }, update: { taskId: "seed-task-1", userId: uid("jane.smith"), content: "Working on migration dependencies." }, create: { id: "seed-task-comment-1", taskId: "seed-task-1", userId: uid("jane.smith"), content: "Working on migration dependencies." } });

  await prisma.documentFolder.upsert({ where: { id: "seed-folder-1" }, update: { name: "Policies", parentId: null }, create: { id: "seed-folder-1", name: "Policies", parentId: null } });
  await prisma.document.upsert({
    where: { id: "seed-doc-1" },
    update: { name: "Employee Handbook 2026", folderId: "seed-folder-1", ownerId: uid("liam.chen"), content: "Policies and onboarding.", fileUrl: "/seed/docs/handbook.pdf", fileSize: 1200000, mimeType: "application/pdf" },
    create: { id: "seed-doc-1", name: "Employee Handbook 2026", folderId: "seed-folder-1", ownerId: uid("liam.chen"), content: "Policies and onboarding.", fileUrl: "/seed/docs/handbook.pdf", fileSize: 1200000, mimeType: "application/pdf" },
  });

  await prisma.boardCategory.upsert({ where: { id: "seed-board-cat-1" }, update: { name: "Announcements" }, create: { id: "seed-board-cat-1", name: "Announcements" } });
  await prisma.boardTopic.upsert({
    where: { id: "seed-board-topic-1" },
    update: { categoryId: "seed-board-cat-1", creatorId: uid("admin"), title: "Welcome", isPinned: true },
    create: { id: "seed-board-topic-1", categoryId: "seed-board-cat-1", creatorId: uid("admin"), title: "Welcome", isPinned: true },
  });
  await prisma.boardPost.upsert({
    where: { id: "seed-board-post-1" },
    update: { topicId: "seed-board-topic-1", authorId: uid("admin"), content: "Use assigned roles for testing." },
    create: { id: "seed-board-post-1", topicId: "seed-board-topic-1", authorId: uid("admin"), content: "Use assigned roles for testing." },
  });

  await prisma.serviceDeskGroup.upsert({ where: { id: "seed-sd-group-1" }, update: { name: "Technical Support", isActive: true }, create: { id: "seed-sd-group-1", name: "Technical Support", isActive: true } });
  await prisma.serviceDeskCategory.upsert({ where: { id: "seed-sd-cat-1" }, update: { groupId: "seed-sd-group-1", name: "Access Issues" }, create: { id: "seed-sd-cat-1", groupId: "seed-sd-group-1", name: "Access Issues" } });
  await prisma.serviceDeskRequest.upsert({
    where: { id: "seed-sd-req-1" },
    update: { groupId: "seed-sd-group-1", categoryId: "seed-sd-cat-1", requesterId: uid("john.doe"), assigneeId: uid("mohit.kumar"), organizationId: "seed-org-acme", title: "Cannot access portal", description: "403 after SSO callback.", status: "open", priority: "high" },
    create: { id: "seed-sd-req-1", groupId: "seed-sd-group-1", categoryId: "seed-sd-cat-1", requesterId: uid("john.doe"), assigneeId: uid("mohit.kumar"), organizationId: "seed-org-acme", title: "Cannot access portal", description: "403 after SSO callback.", status: "open", priority: "high" },
  });
  await prisma.serviceDeskComment.upsert({ where: { id: "seed-sd-comment-1" }, update: { requestId: "seed-sd-req-1", userId: uid("mohit.kumar"), content: "Issue reproduced.", isSystem: false }, create: { id: "seed-sd-comment-1", requestId: "seed-sd-req-1", userId: uid("mohit.kumar"), content: "Issue reproduced.", isSystem: false } });

  const mailbox = await prisma.mailbox.upsert({
    where: { email: "operations@teamwox.local" },
    update: { name: "Operations", imapHost: "imap.teamwox.local", smtpHost: "smtp.teamwox.local", username: "operations@teamwox.local", password: "mailbox-password", isActive: true, lastSync: d(0, 8, 0) },
    create: { id: "seed-mailbox-1", name: "Operations", email: "operations@teamwox.local", imapHost: "imap.teamwox.local", smtpHost: "smtp.teamwox.local", username: "operations@teamwox.local", password: "mailbox-password", isActive: true, lastSync: d(0, 8, 0) },
  });
  await prisma.email.upsert({
    where: { id: "seed-email-1" },
    update: { subject: "Workspace ready", body: "Please validate module access.", fromId: uid("admin"), mailboxId: mailbox.id, status: "inbox", isRead: false, isStarred: true, createdAt: d(-1, 9, 0) },
    create: { id: "seed-email-1", subject: "Workspace ready", body: "Please validate module access.", fromId: uid("admin"), mailboxId: mailbox.id, status: "inbox", isRead: false, isStarred: true, createdAt: d(-1, 9, 0) },
  });
  await prisma.emailRecipient.upsert({ where: { id: "seed-email-rec-1" }, update: { emailId: "seed-email-1", userId: uid("john.doe"), type: "to" }, create: { id: "seed-email-rec-1", emailId: "seed-email-1", userId: uid("john.doe"), type: "to" } });

  await prisma.chatServiceGroup.upsert({ where: { id: "seed-chat-group-1" }, update: { name: "Support", isActive: true }, create: { id: "seed-chat-group-1", name: "Support", isActive: true } });
  await prisma.chatDialog.upsert({ where: { id: "seed-dialog-1" }, update: { subject: "Portal incident", groupId: "seed-chat-group-1", organizationId: "seed-org-acme", status: "open" }, create: { id: "seed-dialog-1", subject: "Portal incident", groupId: "seed-chat-group-1", organizationId: "seed-org-acme", status: "open" } });
  await prisma.chatDialogMember.upsert({ where: { dialogId_userId: { dialogId: "seed-dialog-1", userId: uid("mohit.kumar") } }, update: {}, create: { dialogId: "seed-dialog-1", userId: uid("mohit.kumar") } });
  await prisma.chatMessage.upsert({ where: { id: "seed-chat-msg-1" }, update: { dialogId: "seed-dialog-1", userId: uid("mohit.kumar"), content: "Checking logs now." }, create: { id: "seed-chat-msg-1", dialogId: "seed-dialog-1", userId: uid("mohit.kumar"), content: "Checking logs now." } });

  await prisma.projectCategory.upsert({ where: { id: "seed-proj-cat-1" }, update: { name: "Client Implementation" }, create: { id: "seed-proj-cat-1", name: "Client Implementation" } });
  await prisma.project.upsert({
    where: { id: "seed-project-1" },
    update: { categoryId: "seed-proj-cat-1", name: "Acme ERP Rollout", description: "Implementation project.", status: "active", startDate: d(-10, 9, 0), endDate: d(30, 18, 0) },
    create: { id: "seed-project-1", categoryId: "seed-proj-cat-1", name: "Acme ERP Rollout", description: "Implementation project.", status: "active", startDate: d(-10, 9, 0), endDate: d(30, 18, 0) },
  });
  await prisma.projectMember.upsert({ where: { projectId_userId: { projectId: "seed-project-1", userId: uid("sara.khan") } }, update: { role: "manager" }, create: { projectId: "seed-project-1", userId: uid("sara.khan"), role: "manager" } });
  await prisma.projectPhase.upsert({ where: { id: "seed-phase-1" }, update: { projectId: "seed-project-1", name: "Implementation", order: 1 }, create: { id: "seed-phase-1", projectId: "seed-project-1", name: "Implementation", order: 1 } });
  await prisma.projectTask.upsert({ where: { id: "seed-proj-task-1" }, update: { projectId: "seed-project-1", phaseId: "seed-phase-1", assigneeId: uid("jane.smith"), title: "Build migration script", status: "in_progress", priority: "high", dueDate: d(2, 17, 0) }, create: { id: "seed-proj-task-1", projectId: "seed-project-1", phaseId: "seed-phase-1", assigneeId: uid("jane.smith"), title: "Build migration script", status: "in_progress", priority: "high", dueDate: d(2, 17, 0) } });

  await prisma.productCategory.upsert({ where: { id: "seed-prod-cat-1" }, update: { name: "Software" }, create: { id: "seed-prod-cat-1", name: "Software" } });
  await prisma.product.upsert({ where: { id: "seed-product-1" }, update: { categoryId: "seed-prod-cat-1", name: "TeamWox Core License", price: "199.00", currency: "USD", stock: 500, sku: "TWX-CORE", isActive: true }, create: { id: "seed-product-1", categoryId: "seed-prod-cat-1", name: "TeamWox Core License", price: "199.00", currency: "USD", stock: 500, sku: "TWX-CORE", isActive: true } });

  await prisma.accountingBook.upsert({ where: { id: "seed-book-1" }, update: { organizationId: "seed-org-acme", name: "Acme Ledger", status: "open", currency: "USD" }, create: { id: "seed-book-1", organizationId: "seed-org-acme", name: "Acme Ledger", status: "open", currency: "USD" } });
  await prisma.accountingContract.upsert({ where: { id: "seed-contract-1" }, update: { bookId: "seed-book-1", number: "ACME-2026-001", amount: "25000.00", currency: "USD", status: "active" }, create: { id: "seed-contract-1", bookId: "seed-book-1", number: "ACME-2026-001", amount: "25000.00", currency: "USD", status: "active" } });
  await prisma.accountingTransaction.upsert({ where: { id: "seed-acc-tx-1" }, update: { contractId: "seed-contract-1", type: "credit", amount: "10000.00", description: "Initial payment", date: d(-6, 12, 0) }, create: { id: "seed-acc-tx-1", contractId: "seed-contract-1", type: "credit", amount: "10000.00", description: "Initial payment", date: d(-6, 12, 0) } });

  await prisma.bankAccount.upsert({ where: { id: "seed-bank-1" }, update: { name: "Main USD Account", accountNumber: "AE001000200030001111", bankName: "Emirates Bank", currency: "USD", provider: "manual", balance: "80000.00", isActive: true }, create: { id: "seed-bank-1", name: "Main USD Account", accountNumber: "AE001000200030001111", bankName: "Emirates Bank", currency: "USD", provider: "manual", balance: "80000.00", isActive: true } });
  await prisma.bankTransaction.upsert({ where: { id: "seed-bank-tx-1" }, update: { accountId: "seed-bank-1", type: "credit", amount: "10000.00", currency: "USD", description: "Client payment", status: "recognized", transactionAt: d(-2, 11, 0) }, create: { id: "seed-bank-tx-1", accountId: "seed-bank-1", type: "credit", amount: "10000.00", currency: "USD", description: "Client payment", status: "recognized", transactionAt: d(-2, 11, 0) } });
  await prisma.bankRoutingRule.upsert({ where: { id: "seed-bank-rule-1" }, update: { accountId: "seed-bank-1", name: "Recognize invoice", condition: "{\"referencePrefix\":\"INV-\"}", action: "{\"status\":\"recognized\"}", isActive: true }, create: { id: "seed-bank-rule-1", accountId: "seed-bank-1", name: "Recognize invoice", condition: "{\"referencePrefix\":\"INV-\"}", action: "{\"status\":\"recognized\"}", isActive: true } });

  await prisma.telephonyProvider.upsert({ where: { id: "seed-tel-provider-1" }, update: { name: "Primary SIP", host: "sip.teamwox.local", username: "sip-user", password: "sip-password", isActive: true }, create: { id: "seed-tel-provider-1", name: "Primary SIP", host: "sip.teamwox.local", username: "sip-user", password: "sip-password", isActive: true } });
  await prisma.extension.upsert({ where: { number: "1001" }, update: { userId: uid("admin"), password: "1234", isActive: true }, create: { id: "seed-ext-1001", number: "1001", userId: uid("admin"), password: "1234", isActive: true } });
  await prisma.callLog.upsert({ where: { id: "seed-call-1" }, update: { callerNum: "+971502001001", calleeNum: "1001", calleeId: uid("admin"), direction: "inbound", status: "answered", duration: 180, startedAt: d(-1, 13, 0), endedAt: d(-1, 13, 3) }, create: { id: "seed-call-1", callerNum: "+971502001001", calleeNum: "1001", calleeId: uid("admin"), direction: "inbound", status: "answered", duration: 180, startedAt: d(-1, 13, 0), endedAt: d(-1, 13, 3) } });
  await prisma.telephonyBlacklist.upsert({ where: { number: "+971509999999" }, update: { reason: "Spam calls" }, create: { id: "seed-blacklist-1", number: "+971509999999", reason: "Spam calls" } });

  await prisma.attachment.upsert({ where: { id: "seed-attachment-1" }, update: { fileName: "rollout-checklist.pdf", fileUrl: "/seed/attachments/rollout-checklist.pdf", fileSize: 420000, mimeType: "application/pdf", taskId: "seed-task-1" }, create: { id: "seed-attachment-1", fileName: "rollout-checklist.pdf", fileUrl: "/seed/attachments/rollout-checklist.pdf", fileSize: 420000, mimeType: "application/pdf", taskId: "seed-task-1" } });

  await prisma.notification.upsert({ where: { id: "seed-notification-1" }, update: { userId: uid("john.doe"), type: "task", title: "Task assigned", body: "You were assigned rollout planning.", link: "/tasks", isRead: false }, create: { id: "seed-notification-1", userId: uid("john.doe"), type: "task", title: "Task assigned", body: "You were assigned rollout planning.", link: "/tasks", isRead: false } });
  await prisma.auditLog.upsert({ where: { id: "seed-audit-1" }, update: { userId: uid("admin"), action: "SEED_INIT", module: "administration", details: "Sample data inserted", ipAddress: "127.0.0.1" }, create: { id: "seed-audit-1", userId: uid("admin"), action: "SEED_INIT", module: "administration", details: "Sample data inserted", ipAddress: "127.0.0.1" } });

  for (const setting of [
    ["app.name", "ZedDash"],
    ["app.tagline", "Workspace"],
    ["app_version", "1.1.0-seeded"],
    ["default_language", "en"],
    ["max_upload_size", "134217728"],
    ["seed_last_run", new Date().toISOString()],
  ] as const) {
    await prisma.systemSetting.upsert({
      where: { key: setting[0] },
      update: { value: setting[1] },
      create: { key: setting[0], value: setting[1] },
    });
  }

  const [userCount, roleCount, orgCount, taskCount, projectCount] = await Promise.all([
    prisma.user.count(),
    prisma.group.count(),
    prisma.organization.count(),
    prisma.task.count(),
    prisma.project.count(),
  ]);
  console.log(`Seeded users=${userCount} roles=${roleCount} orgs=${orgCount} tasks=${taskCount} projects=${projectCount}`);
  console.log("Credentials: admin/admin123, john.doe/admin123");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

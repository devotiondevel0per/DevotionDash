import { auth } from "@/auth";
import { NextResponse } from "next/server";
import { evaluateNetworkAccess, getRequestCountry, getRequestIp, getSecurityPolicy } from "@/lib/security-policy";

export default auth(async (req) => {
  const isLoggedIn = !!req.auth;
  const pathname = req.nextUrl.pathname;
  const isLoginPage = pathname === "/login";
  const isForgotPasswordPage = pathname === "/forgot-password";
  const isResetPasswordPage = pathname === "/reset-password";
  const isPublicAuthPage = isLoginPage || isForgotPasswordPage || isResetPasswordPage;
  const isApiAuth = req.nextUrl.pathname.startsWith("/api/auth");
  const isApiPublicBranding = req.nextUrl.pathname === "/api/public/branding";
  const isApiRoute = req.nextUrl.pathname.startsWith("/api");
  const isPublic = req.nextUrl.pathname.startsWith("/chat/widget");

  if (isApiAuth || isApiPublicBranding || isPublic) return NextResponse.next();

  const policy = await getSecurityPolicy();
  const ip = getRequestIp(req.headers);
  const country = getRequestCountry(req.headers);
  const networkCheck = evaluateNetworkAccess(policy, { ip, country });
  if (!networkCheck.allowed) {
    if (isApiRoute) {
      return NextResponse.json({ error: "Blocked by security policy" }, { status: 403 });
    }
    return NextResponse.redirect(new URL("/login", req.nextUrl));
  }

  if (!isLoggedIn && isApiRoute) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!isLoggedIn && !isPublicAuthPage) {
    return NextResponse.redirect(new URL("/login", req.nextUrl));
  }

  if (isLoggedIn && isPublicAuthPage) {
    return NextResponse.redirect(new URL("/home", req.nextUrl));
  }

  if (isLoggedIn) {
    const authAt = Number((req.auth?.user as { authAt?: number } | undefined)?.authAt ?? 0);
    if (Number.isFinite(authAt) && authAt > 0) {
      const sessionAgeMs = Date.now() - authAt;
      if (sessionAgeMs > policy.sessionMaxMinutes * 60 * 1000) {
        if (isApiRoute) {
          return NextResponse.json({ error: "Session expired" }, { status: 401 });
        }
        return NextResponse.redirect(new URL("/login", req.nextUrl));
      }
    }
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|res|uploads).*)"],
};

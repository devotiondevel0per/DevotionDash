﻿"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { usePermissions } from "@/hooks/use-permissions";
import { cn } from "@/lib/utils";
import {
  CalendarDays,
  Check,
  CheckCircle2,
  Eye,
  FilePlus2,
  Link2,
  List,
  ListOrdered,
  Loader2,
  Paperclip,
  Pencil,
  Plus,
  Search,
  Star,
  Trash2,
  Underline,
} from "lucide-react";

type TaskStatus = "opened" | "completed" | "closed";
type TaskType = "task" | "event" | "note";
type TaskPriority = "low" | "normal" | "high";
type TaskView = "overview" | "personal" | "assigned" | "groups" | "all" | "filter";
type TaskCategory = "open" | "closed" | "events" | "notes" | "favorites" | "subordinate" | "all";

type TaskUser = { id: string; fullname: string; email?: string };

type TaskItem = {
  id: string;
  title: string;
  description: string | null;
  type: TaskType;
  status: TaskStatus;
  priority: TaskPriority;
  isPrivate: boolean;
  dueDate: string | null;
  createdAt: string;
  creatorId: string;
  creator: { id: string; name: string; fullname: string };
  assignees: Array<{ id: string; user: { id: string; name: string; fullname: string } }>;
  isFavorite?: boolean;
};

type TaskMetaResponse = {
  users: TaskUser[];
  currentUserId: string;
};

type FilterState = {
  subject: string;
  periodFrom: string;
  periodTo: string;
  authorId: string;
  assigneeId: string;
};

type TaskFormState = {
  id?: string;
  title: string;
  assigneeIds: string[];
  type: TaskType;
  status: TaskStatus;
  priority: TaskPriority;
  dueDate: string;
  isPrivate: boolean;
  descriptionHtml: string;
};

const VIEW_TABS: Array<{ id: TaskView; label: string }> = [
  { id: "overview", label: "Overview" },
  { id: "personal", label: "Personal" },
  { id: "assigned", label: "Assigned" },
  { id: "groups", label: "Groups" },
  { id: "all", label: "All" },
  { id: "filter", label: "Filter" },
];

const CATEGORY_ITEMS: Array<{ id: TaskCategory; label: string }> = [
  { id: "open", label: "Open" },
  { id: "closed", label: "Closed" },
  { id: "events", label: "Events" },
  { id: "notes", label: "Notes" },
  { id: "favorites", label: "Favorites" },
  { id: "subordinate", label: "Subordinate" },
  { id: "all", label: "All" },
];

const EMPTY_FILTERS: FilterState = {
  subject: "",
  periodFrom: "",
  periodTo: "",
  authorId: "",
  assigneeId: "",
};

const EMPTY_FORM: TaskFormState = {
  title: "",
  assigneeIds: [],
  type: "task",
  status: "opened",
  priority: "normal",
  dueDate: "",
  isPrivate: false,
  descriptionHtml: "",
};

function nameOf(user: { name: string; fullname: string }) {
  return user.fullname?.trim() || user.name || "Unknown";
}

function formatDate(value: string | null) {
  if (!value) return "-";
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return "-";
  return dt.toLocaleDateString();
}

function toDateInput(value: string | null) {
  if (!value) return "";
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return "";
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
}

function toHtml(value: string | null) {
  if (!value) return "";
  if (/<[^>]+>/.test(value)) return value;
  return value.replace(/\n/g, "<br/>");
}

function buildParams(view: TaskView, category: TaskCategory, statusScope: string, search: string, filters: FilterState) {
  const params = new URLSearchParams();
  params.set("limit", "500");
  params.set("view", view);
  params.set("category", category);
  if (statusScope !== "all") params.set("status", statusScope);
  if (search.trim()) params.set("search", search.trim());

  if (view === "filter") {
    if (filters.subject.trim()) params.set("subject", filters.subject.trim());
    if (filters.periodFrom) params.set("periodFrom", filters.periodFrom);
    if (filters.periodTo) params.set("periodTo", filters.periodTo);
    if (filters.authorId) params.set("authorId", filters.authorId);
    if (filters.assigneeId) params.set("assigneeId", filters.assigneeId);
  }

  return params;
}

function FilterPanel({
  value,
  onChange,
  users,
  onApply,
  onReset,
}: {
  value: FilterState;
  onChange: (next: FilterState) => void;
  users: TaskUser[];
  onApply: () => void;
  onReset: () => void;
}) {
  return (
    <div className="border-b border-neutral-300 bg-white px-6 py-4">
      <div className="grid gap-3 lg:grid-cols-[1fr_1fr_1fr_1fr_auto]">
        <div className="space-y-1">
          <Label className="text-xs text-slate-600">Subject</Label>
          <Input value={value.subject} onChange={(e) => onChange({ ...value, subject: e.target.value })} className="h-9" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs text-slate-600">Period From</Label>
          <Input type="date" value={value.periodFrom} onChange={(e) => onChange({ ...value, periodFrom: e.target.value })} className="h-9" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs text-slate-600">Period To</Label>
          <Input type="date" value={value.periodTo} onChange={(e) => onChange({ ...value, periodTo: e.target.value })} className="h-9" />
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          <Select value={value.authorId || "all"} onValueChange={(v) => onChange({ ...value, authorId: v && v !== "all" ? v : "" })}>
            <SelectTrigger className="h-9"><SelectValue placeholder="Author" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All authors</SelectItem>
              {users.map((u) => <SelectItem key={`a-${u.id}`} value={u.id}>{u.fullname}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={value.assigneeId || "all"} onValueChange={(v) => onChange({ ...value, assigneeId: v && v !== "all" ? v : "" })}>
            <SelectTrigger className="h-9"><SelectValue placeholder="Assigned" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All assignees</SelectItem>
              {users.map((u) => <SelectItem key={`s-${u.id}`} value={u.id}>{u.fullname}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-end gap-2">
          <Button className="h-9 bg-[#FE0000] text-white hover:bg-[#d40000]" onClick={onApply}>Filter</Button>
          <Button className="h-9" variant="outline" onClick={onReset}>Reset</Button>
        </div>
      </div>
    </div>
  );
}

function EditorToolbar({ onCommand, disabled }: { onCommand: (command: string, value?: string) => void; disabled?: boolean }) {
  return (
    <div className="flex flex-wrap items-center gap-1 border-b bg-slate-50 p-1.5">
      <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={() => onCommand("bold")} disabled={disabled}><span className="font-bold">B</span></Button>
      <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={() => onCommand("italic")} disabled={disabled}><span className="italic">I</span></Button>
      <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={() => onCommand("underline")} disabled={disabled}><Underline className="h-3.5 w-3.5" /></Button>
      <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={() => onCommand("insertUnorderedList")} disabled={disabled}><List className="h-3.5 w-3.5" /></Button>
      <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={() => onCommand("insertOrderedList")} disabled={disabled}><ListOrdered className="h-3.5 w-3.5" /></Button>
      <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={() => {
        const url = window.prompt("Enter URL", "https://");
        if (url) onCommand("createLink", url);
      }} disabled={disabled}><Link2 className="h-3.5 w-3.5" /></Button>
    </div>
  );
}
function TaskModal({
  open,
  onClose,
  onSaved,
  users,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  users: TaskUser[];
  initial: TaskFormState;
}) {
  const [form, setForm] = useState<TaskFormState>(initial);
  const [saving, setSaving] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const editorRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    setForm(initial);
    setFiles([]);
  }, [open, initial]);

  useEffect(() => {
    if (!open || !editorRef.current) return;
    editorRef.current.innerHTML = form.descriptionHtml || "";
  }, [open, form.descriptionHtml]);

  const syncEditor = useCallback(() => {
    const html = editorRef.current?.innerHTML ?? "";
    setForm((prev) => ({ ...prev, descriptionHtml: html }));
  }, []);

  const exec = useCallback((command: string, value?: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    document.execCommand(command, false, value);
    syncEditor();
  }, [syncEditor]);

  async function uploadFiles(taskId: string) {
    if (files.length === 0) return;
    const data = new FormData();
    for (const file of files) data.append("files", file);
    const response = await fetch(`/api/tasks/${taskId}/uploads`, { method: "POST", body: data });
    if (!response.ok) {
      const payload = (await response.json().catch(() => null)) as { error?: string } | null;
      throw new Error(payload?.error ?? "Attachment upload failed");
    }
  }

  async function submit() {
    if (!form.title.trim()) {
      toast.error("Subject is required");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        title: form.title.trim(),
        description: form.descriptionHtml,
        type: form.type,
        status: form.status,
        priority: form.priority,
        dueDate: form.dueDate || null,
        isPrivate: form.isPrivate,
        assigneeIds: form.assigneeIds,
      };

      const response = await fetch(form.id ? `/api/tasks/${form.id}` : "/api/tasks", {
        method: form.id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = (await response.json().catch(() => null)) as { id?: string; error?: string } | null;
      if (!response.ok || !data?.id) throw new Error(data?.error ?? "Save failed");

      await uploadFiles(data.id);
      toast.success(form.id ? "Task updated" : "Task created");
      onSaved();
      onClose();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  const selected = useMemo(() => new Set(form.assigneeIds), [form.assigneeIds]);
  const titleIcon = form.id ? <Pencil className="h-5 w-5 text-[#FE0000]" /> : <FilePlus2 className="h-5 w-5 text-[#FE0000]" />;

  function setDuePreset(daysFromToday: number) {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    now.setDate(now.getDate() + daysFromToday);
    const value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    setForm((prev) => ({ ...prev, dueDate: value }));
  }

  return (
    <Dialog open={open} onOpenChange={(next) => (!next ? onClose() : null)}>
      <DialogContent className="max-h-[92vh] overflow-y-auto p-0 sm:max-w-5xl">
        <DialogHeader className="border-b bg-gradient-to-r from-slate-50 via-red-50 to-slate-50 px-6 py-4">
          <DialogTitle className="flex items-center gap-2 text-2xl">
            {titleIcon}
            <span>{form.id ? "Edit Task" : "Create New Task"}</span>
          </DialogTitle>
          <DialogDescription>Subject, responsible users, status, deadline, rich text, and attachments.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 px-6 py-5 lg:grid-cols-[1fr_0.95fr]">
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Subject *</Label>
              <Input value={form.title} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} />
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <Select value={form.type} onValueChange={(v) => setForm((p) => ({ ...p, type: v as TaskType }))}>
                <SelectTrigger><SelectValue placeholder="Type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="task">Task</SelectItem>
                  <SelectItem value="event">Event</SelectItem>
                  <SelectItem value="note">Note</SelectItem>
                </SelectContent>
              </Select>

              <Select value={form.status} onValueChange={(v) => setForm((p) => ({ ...p, status: v as TaskStatus }))}>
                <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="opened">Open</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>

              <Select value={form.priority} onValueChange={(v) => setForm((p) => ({ ...p, priority: v as TaskPriority }))}>
                <SelectTrigger><SelectValue placeholder="Priority" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>

              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5 text-xs text-slate-600"><CalendarDays className="h-3.5 w-3.5" />Deadline</Label>
                <Input type="date" value={form.dueDate} onChange={(e) => setForm((p) => ({ ...p, dueDate: e.target.value }))} />
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button type="button" size="sm" variant="outline" className="h-8 text-xs" onClick={() => setDuePreset(0)}>Today</Button>
              <Button type="button" size="sm" variant="outline" className="h-8 text-xs" onClick={() => setDuePreset(1)}>Tomorrow</Button>
              <Button type="button" size="sm" variant="outline" className="h-8 text-xs" onClick={() => setDuePreset(3)}>In 3 Days</Button>
              <Button type="button" size="sm" variant="outline" className="h-8 text-xs" onClick={() => setDuePreset(7)}>Next Week</Button>
              <Button type="button" size="sm" variant="ghost" className="h-8 text-xs text-slate-500 hover:text-slate-700" onClick={() => setForm((p) => ({ ...p, dueDate: "" }))}>Clear</Button>
            </div>

            <div className="rounded-md border">
              <EditorToolbar onCommand={exec} disabled={saving} />
              <div
                ref={editorRef}
                className="min-h-56 px-3 py-2 text-sm focus:outline-none"
                contentEditable
                suppressContentEditableWarning
                onInput={syncEditor}
              />
            </div>

            <div className="space-y-2">
              <Label>Attach file</Label>
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" variant="outline" onClick={() => document.getElementById("task-file-input")?.click()}>
                  <Paperclip className="mr-1 h-4 w-4" />Attach
                </Button>
                <input
                  id="task-file-input"
                  className="hidden"
                  type="file"
                  multiple
                  onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
                />
                <span className="text-xs text-slate-500">{files.length > 0 ? `${files.length} file(s)` : "No files"}</span>
                {files.length > 0 ? (
                  <Button type="button" variant="ghost" size="sm" className="h-8 text-xs text-slate-500 hover:text-slate-700" onClick={() => setFiles([])}>
                    Clear files
                  </Button>
                ) : null}
              </div>
            </div>
          </div>

          <div className="space-y-3 rounded border bg-slate-50 p-3">
            <Label>Assigned to</Label>
            <div className="max-h-72 space-y-1 overflow-y-auto rounded border bg-white p-2">
              {users.length === 0 ? <p className="text-xs text-slate-500">No users available</p> : users.map((u) => (
                <label key={u.id} className="flex cursor-pointer gap-2 rounded px-2 py-1.5 hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={selected.has(u.id)}
                    onChange={(e) => {
                      const next = e.target.checked
                        ? Array.from(new Set([...form.assigneeIds, u.id]))
                        : form.assigneeIds.filter((id) => id !== u.id);
                      setForm((p) => ({ ...p, assigneeIds: next }));
                    }}
                  />
                  <span className="min-w-0 text-sm">
                    <span className="block truncate font-medium text-slate-800">{u.fullname}</span>
                    {u.email ? <span className="block truncate text-xs text-slate-500">{u.email}</span> : null}
                  </span>
                </label>
              ))}
            </div>
            <label className="flex items-center gap-2 rounded border bg-white px-3 py-2 text-sm">
              <input type="checkbox" checked={form.isPrivate} onChange={(e) => setForm((p) => ({ ...p, isPrivate: e.target.checked }))} />
              Private task
            </label>
          </div>
        </div>

        <DialogFooter className="border-t px-6 py-3">
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button className="bg-[#FE0000] text-white hover:bg-[#d40000]" onClick={() => void submit()} disabled={saving}>
            {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <FilePlus2 className="mr-1 h-4 w-4" />}
            {form.id ? "Save" : "Add"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function TasksPage() {
  const { can } = usePermissions();
  const canWrite = can("tasks", "write");

  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [users, setUsers] = useState<TaskUser[]>([]);
  const [meId, setMeId] = useState("");
  const [loading, setLoading] = useState(true);

  const [view, setView] = useState<TaskView>("overview");
  const [category, setCategory] = useState<TaskCategory>("all");
  const [statusScope, setStatusScope] = useState("all");
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");

  const [filterDraft, setFilterDraft] = useState<FilterState>(EMPTY_FILTERS);
  const [filterApplied, setFilterApplied] = useState<FilterState>(EMPTY_FILTERS);

  const [formOpen, setFormOpen] = useState(false);
  const [formInitial, setFormInitial] = useState<TaskFormState>(EMPTY_FORM);

  const [refreshToken, setRefreshToken] = useState(0);

  useEffect(() => {
    const t = window.setTimeout(() => setSearch(searchInput.trim()), 220);
    return () => window.clearTimeout(t);
  }, [searchInput]);

  const loadMeta = useCallback(async () => {
    try {
      const response = await fetch("/api/tasks/meta", { cache: "no-store" });
      if (!response.ok) throw new Error();
      const data = (await response.json()) as TaskMetaResponse;
      setUsers(data.users ?? []);
      setMeId(data.currentUserId ?? "");
    } catch {
      toast.error("Failed to load task metadata");
    }
  }, []);

  const loadTasks = useCallback(async () => {
    setLoading(true);
    try {
      const params = buildParams(view, category, statusScope, search, filterApplied);
      const response = await fetch(`/api/tasks?${params.toString()}`, { cache: "no-store" });
      if (!response.ok) {
        const payload = (await response.json().catch(() => null)) as { error?: string } | null;
        throw new Error(payload?.error ?? "Failed to load tasks");
      }
      const data = (await response.json()) as TaskItem[];
      setTasks(Array.isArray(data) ? data : []);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load tasks");
    } finally {
      setLoading(false);
    }
  }, [category, filterApplied, search, statusScope, view]);

  useEffect(() => { void loadMeta(); }, [loadMeta]);
  useEffect(() => { void loadTasks(); }, [loadTasks, refreshToken]);

  const counts = useMemo(() => {
    const map = new Map<TaskCategory, number>();
    for (const item of CATEGORY_ITEMS) map.set(item.id, 0);
    for (const task of tasks) {
      map.set("all", (map.get("all") ?? 0) + 1);
      if (task.status === "opened") map.set("open", (map.get("open") ?? 0) + 1);
      if (task.status !== "opened") map.set("closed", (map.get("closed") ?? 0) + 1);
      if (task.type === "event") map.set("events", (map.get("events") ?? 0) + 1);
      if (task.type === "note") map.set("notes", (map.get("notes") ?? 0) + 1);
      if (task.isFavorite) map.set("favorites", (map.get("favorites") ?? 0) + 1);
      if (meId && task.creatorId !== meId) map.set("subordinate", (map.get("subordinate") ?? 0) + 1);
    }
    return map;
  }, [meId, tasks]);

  function openCreate() {
    setFormInitial(EMPTY_FORM);
    setFormOpen(true);
  }

  function openEdit(task: TaskItem) {
    setFormInitial({
      id: task.id,
      title: task.title,
      assigneeIds: task.assignees.map((entry) => entry.user.id),
      type: task.type,
      status: task.status,
      priority: task.priority,
      dueDate: toDateInput(task.dueDate),
      isPrivate: task.isPrivate,
      descriptionHtml: toHtml(task.description),
    });
    setFormOpen(true);
  }

  async function patchTask(id: string, payload: Record<string, unknown>) {
    const response = await fetch(`/api/tasks/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = (await response.json().catch(() => null)) as TaskItem | { error?: string } | null;
    if (!response.ok || !data || "error" in data) {
      throw new Error((data as { error?: string } | null)?.error ?? "Task update failed");
    }
    const updatedTask = data as TaskItem;
    setTasks((prev) => prev.map((task) => (task.id === id ? updatedTask : task)));
  }

  async function toggleComplete(task: TaskItem) {
    try {
      await patchTask(task.id, { status: task.status === "opened" ? "completed" : "opened" });
      toast.success(task.status === "opened" ? "Task completed" : "Task reopened");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Task update failed");
    }
  }

  async function toggleFavorite(task: TaskItem) {
    try {
      const response = await fetch(`/api/tasks/${task.id}/favorite`, { method: task.isFavorite ? "DELETE" : "POST" });
      const data = (await response.json().catch(() => null)) as { isFavorite: boolean; favoriteCount: number; error?: string } | null;
      if (!response.ok || !data) throw new Error(data?.error ?? "Favorite update failed");
      setTasks((prev) => prev.map((entry) => entry.id === task.id ? { ...entry, isFavorite: data.isFavorite } : entry));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Favorite update failed");
    }
  }

  async function removeTask(task: TaskItem) {
    if (!window.confirm(`Delete task \"${task.title}\"?`)) return;
    try {
      const response = await fetch(`/api/tasks/${task.id}`, { method: "DELETE" });
      if (!response.ok) {
        const payload = (await response.json().catch(() => null)) as { error?: string } | null;
        throw new Error(payload?.error ?? "Delete failed");
      }
      setTasks((prev) => prev.filter((entry) => entry.id !== task.id));
      toast.success("Task deleted");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed");
    }
  }

  return (
    <div className="flex h-full min-h-0 flex-col bg-[#f8f8f8]">
      <div className="border-b bg-white px-4 py-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="text-sm font-semibold text-slate-800">Tasks</h1>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <Input value={searchInput} onChange={(e) => setSearchInput(e.target.value)} placeholder="Search tasks" className="h-8 w-56 pl-8 text-xs" />
            </div>
            <button className="h-8 rounded border bg-white px-2 text-xs hover:bg-slate-50" onClick={() => setRefreshToken((p) => p + 1)} title="Refresh">
              <Loader2 className={cn("h-3.5 w-3.5", loading && "animate-spin")} />
            </button>
            {canWrite ? <Button className="h-8 bg-[#FE0000] text-xs text-white hover:bg-[#d40000]" onClick={openCreate}><Plus className="mr-1 h-4 w-4" />New Task</Button> : null}
          </div>
        </div>
      </div>

      <div className="border-b bg-white px-2 py-1.5">
        <div className="flex items-center gap-1">
          {VIEW_TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setView(tab.id);
                if (tab.id !== "filter") {
                  setFilterDraft(EMPTY_FILTERS);
                  setFilterApplied(EMPTY_FILTERS);
                }
              }}
              className={cn(
                "rounded px-4 py-1.5 text-xs",
                view === tab.id
                  ? "bg-[#FE0000]/10 font-medium text-[#FE0000]"
                  : "text-slate-600 hover:bg-slate-100"
              )}
            >{tab.label}</button>
          ))}
          <div className="ml-auto min-w-44">
            <Select value={statusScope} onValueChange={(value) => setStatusScope(value ?? "all")}>
              <SelectTrigger className="h-8 rounded-sm border-0 bg-white text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="opened">Opened</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {view === "filter" ? (
        <FilterPanel
          value={filterDraft}
          onChange={setFilterDraft}
          users={users}
          onApply={() => {
            setFilterApplied(filterDraft);
            setRefreshToken((p) => p + 1);
          }}
          onReset={() => {
            setFilterDraft(EMPTY_FILTERS);
            setFilterApplied(EMPTY_FILTERS);
            setRefreshToken((p) => p + 1);
          }}
        />
      ) : null}

      <div className="flex min-h-0 flex-1">
        <aside className="w-72 shrink-0 border-r border-neutral-300 bg-[#f0f0f0]">
          <div className="space-y-0.5 py-2">
            {CATEGORY_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => setCategory(item.id)}
                className={cn(
                  "flex w-full items-center justify-between px-6 py-1.5 text-left text-xs",
                  category === item.id ? "bg-white font-medium text-[#FE0000]" : "text-slate-700 hover:bg-white/60"
                )}
              >
                <span>{item.label}</span>
                <span className="text-xs text-slate-500">{counts.get(item.id) ?? 0}</span>
              </button>
            ))}
          </div>
        </aside>

        <section className="min-h-0 flex-1 overflow-auto bg-[#f5f5f5]">
          {loading ? (
            <div className="space-y-2 p-4">{Array.from({ length: 10 }).map((_, idx) => <Skeleton key={idx} className="h-11 w-full rounded-none" />)}</div>
          ) : tasks.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center text-slate-400"><CheckCircle2 className="h-14 w-14 opacity-30" /><p className="mt-3 text-sm">No tasks.</p></div>
          ) : (
            <div className="min-w-[920px]">
              <div className="grid grid-cols-[36px_1.9fr_120px_170px_170px_150px] border-b border-neutral-300 bg-[#eef0f4] px-2 py-2 text-xs font-semibold uppercase tracking-wide text-slate-600">
                <span className="text-center">#</span>
                <span>Subject</span>
                <span>Date</span>
                <span>Responsible</span>
                <span>Author</span>
                <span className="text-right">Actions</span>
              </div>

              {tasks.map((task) => {
                const done = task.status !== "opened";
                return (
                  <div key={task.id} className={cn("grid grid-cols-[36px_1.9fr_120px_170px_170px_150px] items-center border-b border-neutral-300 px-2 py-1.5 text-xs", done ? "bg-red-50/55" : "bg-white hover:bg-slate-50")}>
                    <button className="mx-auto flex h-5 w-5 items-center justify-center rounded border border-slate-400 text-slate-500 hover:border-[#FE0000] hover:text-[#FE0000]" onClick={() => void toggleComplete(task)} title={done ? "Reopen" : "Complete"}>{done ? <Check className="h-3.5 w-3.5" /> : null}</button>
                    <div className="min-w-0 pr-2">
                      <div className="flex items-center gap-1.5">
                        <p className={cn("truncate font-semibold", done && "line-through text-slate-500")}>{task.title}</p>
                        <Badge variant="outline" className={cn("h-5 px-1.5 text-[10px]", task.priority === "high" && "border-red-200 bg-red-100 text-red-700", task.priority === "normal" && "border-amber-200 bg-amber-100 text-amber-700", task.priority === "low" && "border-slate-200 bg-slate-100 text-slate-700")}>{task.priority}</Badge>
                        <Badge variant="outline" className={cn("h-5 px-1.5 text-[10px]", task.type === "task" && "border-slate-200 bg-slate-100 text-slate-700", task.type === "event" && "border-blue-200 bg-blue-100 text-blue-700", task.type === "note" && "border-violet-200 bg-violet-100 text-violet-700")}>{task.type}</Badge>
                      </div>
                      {task.description ? <p className="truncate text-xs text-slate-500" dangerouslySetInnerHTML={{ __html: task.description }} /> : null}
                    </div>
                    <div className="text-xs text-slate-600">{formatDate(task.dueDate)}</div>
                    <div className="truncate text-xs text-slate-700">{task.assignees.length > 0 ? task.assignees.map((entry) => nameOf(entry.user)).join(", ") : "-"}</div>
                    <div className="truncate text-xs text-[#0066c2]">{nameOf(task.creator)}</div>
                    <div className="flex items-center justify-end gap-1">
                      <button className={cn("rounded border p-1", task.isFavorite ? "border-amber-300 bg-amber-50 text-amber-600" : "border-transparent text-slate-400 hover:border-slate-200 hover:text-slate-600")} onClick={() => void toggleFavorite(task)} title="Favorite"><Star className={cn("h-3.5 w-3.5", task.isFavorite && "fill-current")} /></button>
                      <button className="rounded border border-transparent p-1 text-slate-400 hover:border-slate-200 hover:text-slate-600" onClick={() => openEdit(task)} title="Edit" disabled={!canWrite}><Pencil className="h-3 w-3" /></button>
                      <button className="rounded border border-transparent p-1 text-slate-400 hover:border-slate-200 hover:text-slate-600" onClick={() => void toggleComplete(task)} title={task.status === "opened" ? "Complete" : "Reopen"} disabled={!canWrite}>{task.status === "opened" ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}</button>
                      <button className="rounded border border-transparent p-1 text-slate-400 hover:border-red-200 hover:bg-red-50 hover:text-red-600" onClick={() => void removeTask(task)} title="Delete" disabled={!canWrite}><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>
                );
              })}

              <div className="border-t border-neutral-300 bg-[#666] px-4 py-2 text-right text-xs text-white">1 ... {tasks.length} -&gt; {tasks.length}</div>
            </div>
          )}
        </section>
      </div>

      <TaskModal open={formOpen} onClose={() => setFormOpen(false)} onSaved={() => setRefreshToken((p) => p + 1)} users={users} initial={formInitial} />
    </div>
  );
}

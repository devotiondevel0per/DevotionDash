import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireModuleAccess } from "@/lib/api-access";

const SAFE_SELECT = {
  id: true, name: true, email: true,
  imapHost: true, imapPort: true,
  smtpHost: true, smtpPort: true,
  username: true, useSSL: true,
  isActive: true, lastSync: true, createdAt: true,
} as const;

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const accessResult = await requireModuleAccess("email", "manage");
  if (!accessResult.ok) return accessResult.response;

  const { id } = await params;
  try {
    const body = await req.json() as {
      name?: string; email?: string;
      imapHost?: string; imapPort?: number;
      smtpHost?: string; smtpPort?: number;
      username?: string; password?: string;
      useSSL?: boolean; isActive?: boolean;
    };

    const mailbox = await prisma.mailbox.update({
      where: { id },
      data: {
        ...(body.name      !== undefined && { name: body.name }),
        ...(body.email     !== undefined && { email: body.email }),
        ...(body.imapHost  !== undefined && { imapHost: body.imapHost }),
        ...(body.imapPort  !== undefined && { imapPort: body.imapPort }),
        ...(body.smtpHost  !== undefined && { smtpHost: body.smtpHost }),
        ...(body.smtpPort  !== undefined && { smtpPort: body.smtpPort }),
        ...(body.username  !== undefined && { username: body.username }),
        ...(body.password  !== undefined && body.password && { password: body.password }),
        ...(body.useSSL    !== undefined && { useSSL: body.useSSL }),
        ...(body.isActive  !== undefined && { isActive: body.isActive }),
      },
      select: SAFE_SELECT,
    });

    return NextResponse.json(mailbox);
  } catch (error) {
    console.error("[PUT /api/email/mailboxes/[id]]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const accessResult = await requireModuleAccess("email", "manage");
  if (!accessResult.ok) return accessResult.response;

  const { id } = await params;
  try {
    const result = await prisma.$transaction(async (tx) => {
      const deletedEmails = await tx.email.deleteMany({
        where: { mailboxId: id },
      });

      await tx.mailbox.delete({ where: { id } });
      return { deletedEmails: deletedEmails.count };
    });

    return NextResponse.json({ ok: true, deletedEmails: result.deletedEmails });
  } catch (error) {
    console.error("[DELETE /api/email/mailboxes/[id]]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

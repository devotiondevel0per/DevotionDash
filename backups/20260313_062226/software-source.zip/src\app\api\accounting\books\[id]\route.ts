import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const book = await prisma.accountingBook.findUnique({
      where: { id },
      include: {
        organization: { select: { id: true, name: true } },
        contracts: {
          include: { _count: { select: { transactions: true } } },
          orderBy: { createdAt: "desc" },
        },
      },
    });
    if (!book) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json(book);
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const { name, description, status } = await req.json();
    const book = await prisma.accountingBook.update({ where: { id }, data: { name, description, status } });
    return NextResponse.json(book);
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

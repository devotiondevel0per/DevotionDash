import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireModuleAccess } from "@/lib/api-access";

export async function GET() {
  const accessResult = await requireModuleAccess("telephony", "read");
  if (!accessResult.ok) return accessResult.response;

  try {
    const extensions = await prisma.extension.findMany({
      orderBy: { number: "asc" },
      select: {
        id: true,
        userId: true,
        number: true,
        isActive: true,
        createdAt: true,
      },
    });

    return NextResponse.json(extensions);
  } catch (error) {
    console.error("[GET /api/telephony/extensions]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}


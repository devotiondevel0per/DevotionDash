import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireModuleAccess } from "@/lib/api-access";
import { parseMessagePayload } from "@/lib/chat-message";

export async function GET(req: NextRequest) {
  const accessResult = await requireModuleAccess("chat", "read");
  if (!accessResult.ok) return accessResult.response;

  try {
    const { searchParams } = new URL(req.url);
    const groupId = searchParams.get("groupId");
    const status = searchParams.get("status");
    const search = searchParams.get("search");

    const where: Record<string, unknown> = {};
    if (groupId) where.groupId = groupId;
    if (status) where.status = status;
    if (search) {
      where.subject = { contains: search };
    }
    if (!accessResult.ctx.access.isAdmin) {
      where.members = { some: { userId: accessResult.ctx.userId } };
    }

    const dialogs = await prisma.chatDialog.findMany({
      where,
      include: {
        group: { select: { id: true, name: true } },
        organization: { select: { id: true, name: true } },
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                fullname: true,
                photoUrl: true,
                isActive: true,
                lastActivity: true,
              },
            },
          },
        },
        messages: {
          orderBy: { createdAt: "desc" },
          take: 1,
          include: {
            user: { select: { id: true, name: true, fullname: true } },
          },
        },
        _count: {
          select: { members: true },
        },
      },
      orderBy: { updatedAt: "desc" },
    });

    return NextResponse.json(
      dialogs.map((dialog) => ({
        ...dialog,
        messages: dialog.messages.map((message) => ({
          ...message,
          payload: parseMessagePayload(message.content).payload,
        })),
      }))
    );
  } catch (error) {
    console.error("[GET /api/chat/dialogs]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const accessResult = await requireModuleAccess("chat", "write");
  if (!accessResult.ok) return accessResult.response;

  try {
    const body = await req.json();
    const { subject, groupId, memberIds, organizationId } = body;

    if (!Array.isArray(memberIds)) {
      return NextResponse.json({ error: "memberIds must be an array" }, { status: 400 });
    }

    // Deduplicate memberIds and always include the current user
    const allMemberIds = Array.from(new Set([...memberIds, accessResult.ctx.userId])) as string[];

    const dialog = await prisma.chatDialog.create({
      data: {
        subject: subject ?? null,
        ...(groupId ? { groupId } : {}),
        ...(organizationId ? { organizationId } : {}),
        members: {
          create: allMemberIds.map((userId: string) => ({ userId })),
        },
      },
      include: {
        group: { select: { id: true, name: true } },
        organization: { select: { id: true, name: true } },
        members: {
          include: {
            user: { select: { id: true, name: true, fullname: true, photoUrl: true } },
          },
        },
      },
    });

    return NextResponse.json(dialog, { status: 201 });
  } catch (error) {
    console.error("[POST /api/chat/dialogs]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

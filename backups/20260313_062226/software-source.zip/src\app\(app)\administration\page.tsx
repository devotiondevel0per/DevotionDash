"use client";

import { useEffect, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { moduleIds, type ModuleId, type PermissionAction, type RolePermissionConfig } from "@/lib/permissions";
import { cn } from "@/lib/utils";
import { BarChart3, Blocks, Building2, FileClock, KeyRound, LayoutDashboard, Palette, RefreshCw, Save, Shield, Sparkles, Trash2, UserPlus, Users } from "lucide-react";
import { DEFAULT_SECURITY_POLICY, parseListFromText, parseSecurityPolicy, serializeSecurityPolicy, type SecurityPolicy } from "@/lib/security-policy";
import { BRANDING_UPDATED_EVENT, DEFAULT_APP_NAME, DEFAULT_APP_TAGLINE } from "@/lib/branding";

type RoleSummary = { id: string; name: string; color: string; memberCount: number; permissions: RolePermissionConfig | null };
type AdminUser = {
  id: string;
  login: string;
  email: string;
  name: string;
  surname: string;
  fullname: string;
  position: string;
  department: string;
  isAdmin: boolean;
  isActive: boolean;
  workState: number;
  lastActivity?: string | null;
  createdAt?: string;
  roles: Array<{ id: string; name: string; color: string }>;
  accessibleModules: string[];
};
type NewUserForm = {
  login: string;
  email: string;
  password: string;
  name: string;
  surname: string;
  fullname: string;
  position: string;
  department: string;
  isAdmin: boolean;
  isActive: boolean;
  roleIds: string[];
};
type PermissionResponse = { isAdmin: boolean; permissions: Record<string, { read: boolean; write: boolean; manage: boolean }>; accessibleModules: string[] };
type SettingsForm = {
  appName: string;
  appTagline: string;
  supportEmail: string;
  defaultTimezone: string;
  themePrimary: string;
  sidebarFrom: string;
  sidebarMid: string;
  sidebarTo: string;
  topbarFrom: string;
  topbarMid: string;
  topbarTo: string;
  topbarAccent: string;
  aiModel: string;
};
type ModuleToggle = { id: ModuleId; enabled: boolean; locked: boolean };
type AuditLogItem = { id: string; action: string; module: string; details?: string | null; createdAt: string; user: { name: string } | null };
type AdminInsight = { summary: string; highlights: string[]; risks: string[]; actions: string[]; generatedAt: string; fallback: boolean };
type ReportModule = { moduleId: string; label: string; total: number; recent: number; backlog: number; trend: "up" | "flat" | "down" };
type ReportEmployee = { userId: string; name: string; email: string; department: string; roles: string[]; isActive: boolean; lastActivity: string | null; tasksAssigned: number; tasksCompleted: number; tasksOverdue: number; ticketsAssigned: number; ticketsClosed: number; emailsSent: number; activityScore: number };
type ReportInsight = { summary: string; highlights: string[]; risks: string[]; actions: string[]; source: string; fallback: boolean };
type ReportPayload = {
  generatedAt: string;
  days: number;
  timezone: string;
  totals: { users: number; activeUsers: number; unreadEmails: number; openServiceRequests: number; sentEmails: number; auditEvents: number };
  modules: ReportModule[];
  employees: ReportEmployee[];
  insight: ReportInsight | null;
};
type DepartmentItem = {
  id: string;
  name: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};
type SecurityForm = {
  ipAllowlistText: string;
  ipBlocklistText: string;
  countryAllowlistText: string;
  countryBlocklistText: string;
  rateMaxAttempts: number;
  rateWindowMinutes: number;
  rateLockMinutes: number;
  minPasswordLength: number;
  requireUpper: boolean;
  requireLower: boolean;
  requireNumber: boolean;
  requireSymbol: boolean;
  enforce2FAForAdmins: boolean;
  sessionMaxMinutes: number;
};
type UserTwoFactorView = {
  enabled: boolean;
  backupCodesRemaining: number;
  updatedAt: string | null;
  hasSecret: boolean;
};

const moduleLabels: Record<ModuleId, string> = { home: "Home", tasks: "Tasks", projects: "Projects", documents: "Documents", email: "E-Mail", board: "Board", clients: "Organizations", contacts: "Contacts", team: "Team", calendar: "Calendar", chat: "Chat", servicedesk: "Service Desk", products: "Products", accounting: "Accounting", ebank: "e-Bank", telephony: "Telephony", search: "Search", administration: "Administration" };
const DEFAULT_SETTINGS: SettingsForm = { appName: DEFAULT_APP_NAME, appTagline: DEFAULT_APP_TAGLINE, supportEmail: "", defaultTimezone: "UTC", themePrimary: "#FE0000", sidebarFrom: "#6e0d14", sidebarMid: "#560d14", sidebarTo: "#45111a", topbarFrom: "#670b11", topbarMid: "#8e0c14", topbarTo: "#bf101a", topbarAccent: "#FE0000", aiModel: "qwen2.5:7b" };
const actions: PermissionAction[] = ["read", "write", "manage"];
const EMPTY_NEW_USER_FORM: NewUserForm = {
  login: "",
  email: "",
  password: "",
  name: "",
  surname: "",
  fullname: "",
  position: "",
  department: "",
  isAdmin: false,
  isActive: true,
  roleIds: [],
};
const DEPARTMENTS_SETTING_KEY = "org.departments.catalog";

function parseDepartmentsFromSetting(raw: string | undefined): DepartmentItem[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    const nowIso = new Date().toISOString();
    return parsed
      .map((item): DepartmentItem | null => {
        if (!item || typeof item !== "object") return null;
        const source = item as Record<string, unknown>;
        const name = String(source.name ?? "").trim();
        if (!name) return null;
        const id = String(source.id ?? "").trim() || crypto.randomUUID();
        const createdAt = String(source.createdAt ?? "").trim() || nowIso;
        const updatedAt = String(source.updatedAt ?? "").trim() || nowIso;
        return {
          id,
          name,
          isActive: source.isActive !== false,
          createdAt,
          updatedAt,
        };
      })
      .filter((item): item is DepartmentItem => Boolean(item))
      .sort((a, b) => a.name.localeCompare(b.name));
  } catch {
    return [];
  }
}

function serializeDepartments(departments: DepartmentItem[]) {
  return JSON.stringify(
    departments.map((department) => ({
      id: department.id,
      name: department.name.trim(),
      isActive: department.isActive,
      createdAt: department.createdAt,
      updatedAt: department.updatedAt,
    }))
  );
}

function toSecurityForm(policy: SecurityPolicy): SecurityForm {
  return {
    ipAllowlistText: policy.ipAllowlist.join("\n"),
    ipBlocklistText: policy.ipBlocklist.join("\n"),
    countryAllowlistText: policy.countryAllowlist.join("\n"),
    countryBlocklistText: policy.countryBlocklist.join("\n"),
    rateMaxAttempts: policy.loginRateLimit.maxAttempts,
    rateWindowMinutes: policy.loginRateLimit.windowMinutes,
    rateLockMinutes: policy.loginRateLimit.lockMinutes,
    minPasswordLength: policy.passwordPolicy.minLength,
    requireUpper: policy.passwordPolicy.requireUpper,
    requireLower: policy.passwordPolicy.requireLower,
    requireNumber: policy.passwordPolicy.requireNumber,
    requireSymbol: policy.passwordPolicy.requireSymbol,
    enforce2FAForAdmins: policy.enforce2FAForAdmins,
    sessionMaxMinutes: policy.sessionMaxMinutes,
  };
}

function toSecurityPolicy(form: SecurityForm): SecurityPolicy {
  return {
    ipAllowlist: parseListFromText(form.ipAllowlistText),
    ipBlocklist: parseListFromText(form.ipBlocklistText),
    countryAllowlist: parseListFromText(form.countryAllowlistText).map((code) => code.toUpperCase()),
    countryBlocklist: parseListFromText(form.countryBlocklistText).map((code) => code.toUpperCase()),
    loginRateLimit: {
      maxAttempts: Math.max(1, Math.min(50, Math.round(form.rateMaxAttempts || DEFAULT_SECURITY_POLICY.loginRateLimit.maxAttempts))),
      windowMinutes: Math.max(1, Math.min(120, Math.round(form.rateWindowMinutes || DEFAULT_SECURITY_POLICY.loginRateLimit.windowMinutes))),
      lockMinutes: Math.max(1, Math.min(240, Math.round(form.rateLockMinutes || DEFAULT_SECURITY_POLICY.loginRateLimit.lockMinutes))),
    },
    passwordPolicy: {
      minLength: Math.max(8, Math.min(128, Math.round(form.minPasswordLength || DEFAULT_SECURITY_POLICY.passwordPolicy.minLength))),
      requireUpper: form.requireUpper,
      requireLower: form.requireLower,
      requireNumber: form.requireNumber,
      requireSymbol: form.requireSymbol,
    },
    enforce2FAForAdmins: form.enforce2FAForAdmins,
    sessionMaxMinutes: Math.max(15, Math.min(60 * 24 * 30, Math.round(form.sessionMaxMinutes || DEFAULT_SECURITY_POLICY.sessionMaxMinutes))),
  };
}

function clonePermissions(input?: RolePermissionConfig | null): RolePermissionConfig {
  if (!input) return {};
  const out: RolePermissionConfig = {};
  for (const moduleId of moduleIds) {
    const current = input[moduleId];
    if (current?.length) out[moduleId] = [...current];
  }
  return out;
}

function applyAction(config: RolePermissionConfig, moduleId: ModuleId, action: PermissionAction, enabled: boolean) {
  const current = new Set(config[moduleId] ?? []);
  if (enabled) {
    if (action === "read") current.add("read");
    if (action === "write") { current.add("read"); current.add("write"); }
    if (action === "manage") { current.add("read"); current.add("write"); current.add("manage"); }
  } else {
    if (action === "manage") current.delete("manage");
    if (action === "write") { current.delete("write"); current.delete("manage"); }
    if (action === "read") { current.delete("read"); current.delete("write"); current.delete("manage"); }
  }
  if (current.size === 0) delete config[moduleId];
  else config[moduleId] = Array.from(current);
}

function normalizeHex(value: string, fallback: string) {
  const safe = value.trim();
  return /^#[0-9a-fA-f]{6}$/.test(safe) ? safe : fallback;
}

function applyRuntimeTheme(form: SettingsForm) {
  const root = document.documentElement;
  root.style.setProperty("--primary", normalizeHex(form.themePrimary, "#FE0000"));
  root.style.setProperty("--ring", normalizeHex(form.themePrimary, "#FE0000"));
  root.style.setProperty("--twx-sidebar-from", normalizeHex(form.sidebarFrom, "#6e0d14"));
  root.style.setProperty("--twx-sidebar-mid", normalizeHex(form.sidebarMid, "#560d14"));
  root.style.setProperty("--twx-sidebar-to", normalizeHex(form.sidebarTo, "#45111a"));
  root.style.setProperty("--twx-topbar-from", normalizeHex(form.topbarFrom, "#670b11"));
  root.style.setProperty("--twx-topbar-mid", normalizeHex(form.topbarMid, "#8e0c14"));
  root.style.setProperty("--twx-topbar-to", normalizeHex(form.topbarTo, "#bf101a"));
  root.style.setProperty("--twx-topbar-accent", normalizeHex(form.topbarAccent, "#FE0000"));
  window.dispatchEvent(new CustomEvent(BRANDING_UPDATED_EVENT, { detail: { appName: form.appName.trim() || DEFAULT_APP_NAME, appTagline: form.appTagline.trim() || DEFAULT_APP_TAGLINE } }));
}

function formatDateTime(value: string | null | undefined, timezone: string) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  try {
    return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZone: timezone || "UTC" }).format(date);
  } catch {
    return date.toLocaleString();
  }
}

function generateStrongPassword(length = 14) {
  const source = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*_-+=";
  const chars = Array.from(crypto.getRandomValues(new Uint32Array(length))).map((value) => source[value % source.length]);
  return chars.join("");
}

export default function AdministrationPage() {
  const [section, setSection] = useState<"overview" | "users" | "roles" | "settings" | "modules" | "security" | "reports" | "logs">("overview");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [permissionData, setPermissionData] = useState<PermissionResponse | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [departments, setDepartments] = useState<DepartmentItem[]>([]);
  const [roles, setRoles] = useState<RoleSummary[]>([]);
  const [moduleToggles, setModuleToggles] = useState<ModuleToggle[]>([]);
  const [settingsForm, setSettingsForm] = useState<SettingsForm>(DEFAULT_SETTINGS);
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  const [insight, setInsight] = useState<AdminInsight | null>(null);
  const [insightLoading, setInsightLoading] = useState(false);
  const [reportDays, setReportDays] = useState(30);
  const [reports, setReports] = useState<ReportPayload | null>(null);
  const [reportsLoading, setReportsLoading] = useState(false);
  const [reportsInsightLoading, setReportsInsightLoading] = useState(false);
  const [userLogs, setUserLogs] = useState<AuditLogItem[]>([]);
  const [userLogsLoading, setUserLogsLoading] = useState(false);
  const [userActionSaving, setUserActionSaving] = useState(false);
  const [userPassword, setUserPassword] = useState("");
  const [userSearch, setUserSearch] = useState("");
  const [createUserOpen, setCreateUserOpen] = useState(false);
  const [createUserSaving, setCreateUserSaving] = useState(false);
  const [departmentDialogOpen, setDepartmentDialogOpen] = useState(false);
  const [departmentSaving, setDepartmentSaving] = useState(false);
  const [departmentNameInput, setDepartmentNameInput] = useState("");
  const [departmentDraft, setDepartmentDraft] = useState<DepartmentItem[]>([]);
  const [securityForm, setSecurityForm] = useState<SecurityForm>(() => toSecurityForm(DEFAULT_SECURITY_POLICY));
  const [securitySaving, setSecuritySaving] = useState(false);
  const [newUserForm, setNewUserForm] = useState<NewUserForm>(EMPTY_NEW_USER_FORM);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [selectedUserTwoFactor, setSelectedUserTwoFactor] = useState<UserTwoFactorView | null>(null);
  const [userTwoFactorLoading, setUserTwoFactorLoading] = useState(false);
  const [userTwoFactorSaving, setUserTwoFactorSaving] = useState(false);
  const [userTwoFactorSetup, setUserTwoFactorSetup] = useState<{ secret: string; otpAuthUri: string; backupCodes: string[] } | null>(null);
  const [selectedUserRoleIds, setSelectedUserRoleIds] = useState<string[]>([]);
  const [selectedUserGrants, setSelectedUserGrants] = useState<RolePermissionConfig>({});
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [roleName, setRoleName] = useState("");
  const [roleColor, setRoleColor] = useState("#3B4A61");
  const [rolePermissions, setRolePermissions] = useState<RolePermissionConfig>({});

  const canManage = permissionData?.isAdmin || permissionData?.permissions?.administration?.manage;
  const selectedUser = users.find((user) => user.id === selectedUserId) ?? null;
  const timezone = reports?.timezone || settingsForm.defaultTimezone || "UTC";

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) => `${u.fullname} ${u.login} ${u.email} ${u.department}`.toLowerCase().includes(q));
  }, [users, userSearch]);

  async function loadUserGrants(userId: string) {
    try {
      const response = await fetch(`/api/administration/users/${userId}/permissions`, { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to load direct permissions");
      const data = (await response.json()) as { grants?: RolePermissionConfig };
      setSelectedUserGrants(clonePermissions(data.grants ?? {}));
    } catch {
      setSelectedUserGrants({});
    }
  }

  async function loadUserLogs(userId: string) {
    setUserLogsLoading(true);
    try {
      const response = await fetch(`/api/administration/logs?userId=${encodeURIComponent(userId)}&limit=60`, { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to load user logs");
      const data = (await response.json()) as AuditLogItem[];
      setUserLogs(Array.isArray(data) ? data : []);
    } catch {
      setUserLogs([]);
    } finally {
      setUserLogsLoading(false);
    }
  }

  async function loadUserTwoFactor(userId: string) {
    setUserTwoFactorLoading(true);
    try {
      const response = await fetch(`/api/administration/users/${userId}/2fa`, { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to load 2-step status");
      const data = (await response.json()) as UserTwoFactorView;
      setSelectedUserTwoFactor({
        enabled: Boolean(data.enabled),
        backupCodesRemaining: Number(data.backupCodesRemaining ?? 0),
        hasSecret: Boolean(data.hasSecret),
        updatedAt: data.updatedAt ?? null,
      });
    } catch {
      setSelectedUserTwoFactor(null);
    } finally {
      setUserTwoFactorLoading(false);
    }
  }

  async function fetchAll() {
    setLoading(true);
    setError(null);
    try {
      const [permRes, usersRes, rolesRes, modulesRes, settingsRes] = await Promise.all([
        fetch("/api/permissions", { cache: "no-store" }),
        fetch("/api/administration/users", { cache: "no-store" }),
        fetch("/api/administration/roles", { cache: "no-store" }),
        fetch("/api/administration/modules", { cache: "no-store" }),
        fetch("/api/administration/settings", { cache: "no-store" }),
      ]);
      if (!permRes.ok || !usersRes.ok || !rolesRes.ok || !modulesRes.ok || !settingsRes.ok) throw new Error("Failed to load administration data");

      const permJson = (await permRes.json()) as PermissionResponse;
      const usersJson = (await usersRes.json()) as AdminUser[];
      const rolesJson = (await rolesRes.json()) as { roles: RoleSummary[] };
      const modulesJson = (await modulesRes.json()) as { modules: ModuleToggle[] };
      const settingsJson = (await settingsRes.json()) as Record<string, string>;

      setPermissionData(permJson);
      setUsers(usersJson);
      setRoles(rolesJson.roles ?? []);
      setModuleToggles(modulesJson.modules ?? []);
      setSettingsForm({ appName: settingsJson["app.name"] ?? DEFAULT_SETTINGS.appName, appTagline: settingsJson["app.tagline"] ?? DEFAULT_SETTINGS.appTagline, supportEmail: settingsJson["app.supportEmail"] ?? DEFAULT_SETTINGS.supportEmail, defaultTimezone: settingsJson["system.defaultTimezone"] ?? DEFAULT_SETTINGS.defaultTimezone, themePrimary: settingsJson["theme.primary"] ?? DEFAULT_SETTINGS.themePrimary, sidebarFrom: settingsJson["theme.sidebar.from"] ?? DEFAULT_SETTINGS.sidebarFrom, sidebarMid: settingsJson["theme.sidebar.mid"] ?? DEFAULT_SETTINGS.sidebarMid, sidebarTo: settingsJson["theme.sidebar.to"] ?? DEFAULT_SETTINGS.sidebarTo, topbarFrom: settingsJson["theme.topbar.from"] ?? DEFAULT_SETTINGS.topbarFrom, topbarMid: settingsJson["theme.topbar.mid"] ?? DEFAULT_SETTINGS.topbarMid, topbarTo: settingsJson["theme.topbar.to"] ?? DEFAULT_SETTINGS.topbarTo, topbarAccent: settingsJson["theme.topbar.accent"] ?? DEFAULT_SETTINGS.topbarAccent, aiModel: settingsJson["ai.model"] ?? DEFAULT_SETTINGS.aiModel });
      setSecurityForm(toSecurityForm(parseSecurityPolicy(settingsJson["security.policy.v1"])));
      const parsedDepartments = parseDepartmentsFromSetting(settingsJson[DEPARTMENTS_SETTING_KEY]);
      if (parsedDepartments.length > 0) {
        setDepartments(parsedDepartments);
      } else {
        const nowIso = new Date().toISOString();
        const fallbackDepartments = Array.from(
          new Set(
            usersJson
              .map((user) => user.department?.trim())
              .filter((department): department is string => Boolean(department))
          )
        )
          .sort((a, b) => a.localeCompare(b))
          .map((name) => ({
            id: crypto.randomUUID(),
            name,
            isActive: true,
            createdAt: nowIso,
            updatedAt: nowIso,
          }));
        setDepartments(fallbackDepartments);
      }

      if (!selectedUserId && usersJson.length > 0) {
        setSelectedUserId(usersJson[0].id);
        setSelectedUserRoleIds(usersJson[0].roles.map((role) => role.id));
        await loadUserGrants(usersJson[0].id);
        await loadUserLogs(usersJson[0].id);
        await loadUserTwoFactor(usersJson[0].id);
      }
      if (!selectedRoleId && rolesJson.roles?.length > 0) {
        const role = rolesJson.roles[0];
        setSelectedRoleId(role.id);
        setRoleName(role.name);
        setRoleColor(role.color);
        setRolePermissions(clonePermissions(role.permissions));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load administration data");
    } finally {
      setLoading(false);
    }
  }

  async function loadLogs() {
    try {
      const response = await fetch("/api/administration/logs?limit=200", { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to load logs");
      const data = (await response.json()) as AuditLogItem[];
      setLogs(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load logs");
    }
  }

  async function loadReports(withInsight = false) {
    if (withInsight) setReportsInsightLoading(true);
    else setReportsLoading(true);
    try {
      const response = await fetch(`/api/administration/reports?days=${reportDays}${withInsight ? "&insight=1" : ""}`, { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to load reports");
      const data = (await response.json()) as ReportPayload;
      setReports(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load reports");
    } finally {
      if (withInsight) setReportsInsightLoading(false);
      else setReportsLoading(false);
    }
  }

  useEffect(() => { void fetchAll(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (section === "logs") void loadLogs();
    if (section === "reports" && !reports && !reportsLoading) void loadReports();
  }, [section, reports, reportsLoading]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!selectedUserId) {
      setUserLogs([]);
      setSelectedUserGrants({});
      setSelectedUserTwoFactor(null);
      setUserTwoFactorSetup(null);
      return;
    }
    void loadUserGrants(selectedUserId);
    void loadUserLogs(selectedUserId);
    void loadUserTwoFactor(selectedUserId);
  }, [selectedUserId]); // eslint-disable-line react-hooks/exhaustive-deps

  async function saveSettings() {
    setSaving(true);
    setError(null);
    try {
      const settingsPayload: Record<string, string> = {
        "app.name": settingsForm.appName.trim() || DEFAULT_APP_NAME,
        "app.tagline": settingsForm.appTagline.trim() || DEFAULT_APP_TAGLINE,
        "app.supportEmail": settingsForm.supportEmail.trim(),
        "system.defaultTimezone": settingsForm.defaultTimezone.trim() || "UTC",
        "theme.primary": normalizeHex(settingsForm.themePrimary, "#FE0000"),
        "theme.sidebar.from": normalizeHex(settingsForm.sidebarFrom, "#6e0d14"),
        "theme.sidebar.mid": normalizeHex(settingsForm.sidebarMid, "#560d14"),
        "theme.sidebar.to": normalizeHex(settingsForm.sidebarTo, "#45111a"),
        "theme.topbar.from": normalizeHex(settingsForm.topbarFrom, "#670b11"),
        "theme.topbar.mid": normalizeHex(settingsForm.topbarMid, "#8e0c14"),
        "theme.topbar.to": normalizeHex(settingsForm.topbarTo, "#bf101a"),
        "theme.topbar.accent": normalizeHex(settingsForm.topbarAccent, "#FE0000"),
        "ai.model": settingsForm.aiModel.trim() || "qwen2.5:7b",
      };
      const response = await fetch("/api/administration/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ settings: settingsPayload }) });
      if (!response.ok) throw new Error("Failed to save settings");
      applyRuntimeTheme(settingsForm);
      await fetchAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save settings");
    } finally {
      setSaving(false);
    }
  }

  async function saveSecurityPolicy() {
    setSecuritySaving(true);
    setError(null);
    try {
      const policy = toSecurityPolicy(securityForm);
      const response = await fetch("/api/administration/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          settings: {
            "security.policy.v1": serializeSecurityPolicy(policy),
          },
        }),
      });
      if (!response.ok) throw new Error("Failed to save security policy");
      setSecurityForm(toSecurityForm(policy));
      await fetchAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save security policy");
    } finally {
      setSecuritySaving(false);
    }
  }

  async function saveModuleToggles() {
    setSaving(true);
    setError(null);
    try {
      const enabledModules = moduleToggles.filter((m) => m.enabled).map((m) => m.id);
      const response = await fetch("/api/administration/modules", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabledModules }) });
      if (!response.ok) throw new Error("Failed to save module toggles");
      await fetchAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save module toggles");
    } finally {
      setSaving(false);
    }
  }

  async function saveUserRoles() {
    if (!selectedUserId) return;
    setSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/administration/users/${selectedUserId}/roles`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ groupIds: selectedUserRoleIds }) });
      if (!response.ok) throw new Error("Failed to save user roles");
      await fetchAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save user roles");
    } finally {
      setSaving(false);
    }
  }

  async function saveUserGrants() {
    if (!selectedUserId) return;
    setSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/administration/users/${selectedUserId}/permissions`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ grants: selectedUserGrants }) });
      if (!response.ok) throw new Error("Failed to save user direct permissions");
      await fetchAll();
      await loadUserGrants(selectedUserId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save user direct permissions");
    } finally {
      setSaving(false);
    }
  }

  async function updateSelectedUser(patch: { isActive?: boolean; isAdmin?: boolean; workState?: number; department?: string }) {
    if (!selectedUserId) return;
    setUserActionSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/administration/users/${selectedUserId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Failed to update user");
      }
      await fetchAll();
      await loadUserLogs(selectedUserId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update user");
    } finally {
      setUserActionSaving(false);
    }
  }

  async function manageSelectedUserTwoFactor(action: "enable" | "disable" | "rotate" | "backup") {
    if (!selectedUserId) return;
    setUserTwoFactorSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/administration/users/${selectedUserId}/2fa`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = (await response.json().catch(() => ({}))) as {
        error?: string;
        secret?: string;
        otpAuthUri?: string;
        backupCodes?: string[];
      };
      if (!response.ok) throw new Error(data.error ?? "2-step update failed");

      if (data.secret || data.backupCodes) {
        setUserTwoFactorSetup({
          secret: data.secret ?? "",
          otpAuthUri: data.otpAuthUri ?? "",
          backupCodes: data.backupCodes ?? [],
        });
      } else {
        setUserTwoFactorSetup(null);
      }
      await loadUserTwoFactor(selectedUserId);
      await loadUserLogs(selectedUserId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "2-step update failed");
    } finally {
      setUserTwoFactorSaving(false);
    }
  }

  async function saveSelectedUserPassword() {
    if (!selectedUserId) return;
    const password = userPassword.trim();
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    setUserActionSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/administration/users/${selectedUserId}/password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Failed to change password");
      }
      setUserPassword("");
      await loadUserLogs(selectedUserId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to change password");
    } finally {
      setUserActionSaving(false);
    }
  }

  async function createUser() {
    const payload: NewUserForm = {
      ...newUserForm,
      login: newUserForm.login.trim(),
      email: newUserForm.email.trim(),
      password: newUserForm.password,
      name: newUserForm.name.trim(),
      surname: newUserForm.surname.trim(),
      fullname: newUserForm.fullname.trim(),
      position: newUserForm.position.trim(),
      department: newUserForm.department.trim(),
      roleIds: Array.from(new Set(newUserForm.roleIds)),
    };

    if (!payload.login || !payload.email || !payload.name || payload.password.length < 8) {
      setError("Login, email, first name, and password (min 8 chars) are required.");
      return;
    }

    setCreateUserSaving(true);
    setError(null);
    try {
      const response = await fetch("/api/administration/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json().catch(() => ({}))) as { id?: string; error?: string };
      if (!response.ok) {
        throw new Error(data.error ?? "Failed to create user");
      }

      const createdUserId = data.id ?? null;
      setCreateUserOpen(false);
      setNewUserForm(EMPTY_NEW_USER_FORM);
      await fetchAll();
      if (createdUserId) {
        setSelectedUserId(createdUserId);
        const createdRoleIds = payload.roleIds;
        setSelectedUserRoleIds(createdRoleIds);
        await loadUserGrants(createdUserId);
        await loadUserLogs(createdUserId);
        await loadUserTwoFactor(createdUserId);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create user");
    } finally {
      setCreateUserSaving(false);
    }
  }

  function openDepartmentDialog() {
    setDepartmentDraft(
      departments
        .map((department) => ({ ...department }))
        .sort((a, b) => a.name.localeCompare(b.name))
    );
    setDepartmentNameInput("");
    setDepartmentDialogOpen(true);
  }

  function addDepartmentToDraft() {
    const name = departmentNameInput.trim();
    if (!name) return;
    const duplicate = departmentDraft.some(
      (department) => department.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      setError("Department already exists.");
      return;
    }
    const nowIso = new Date().toISOString();
    setDepartmentDraft((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        name,
        isActive: true,
        createdAt: nowIso,
        updatedAt: nowIso,
      },
    ]);
    setDepartmentNameInput("");
    setError(null);
  }

  async function saveDepartments() {
    setDepartmentSaving(true);
    setError(null);
    try {
      const normalized = departmentDraft
        .map((department) => ({
          ...department,
          name: department.name.trim(),
          updatedAt: new Date().toISOString(),
        }))
        .filter((department) => department.name.length > 0)
        .sort((a, b) => a.name.localeCompare(b.name));

      const response = await fetch("/api/administration/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          settings: {
            [DEPARTMENTS_SETTING_KEY]: serializeDepartments(normalized),
          },
        }),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "Failed to save departments");
      }
      setDepartments(normalized);
      setDepartmentDialogOpen(false);
      setDepartmentNameInput("");
      setDepartmentDraft([]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save departments");
    } finally {
      setDepartmentSaving(false);
    }
  }

  async function createRole() {
    if (!roleName.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const response = await fetch("/api/administration/roles", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: roleName.trim(), color: roleColor, permissions: rolePermissions }) });
      if (!response.ok) throw new Error("Failed to create role");
      await fetchAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create role");
    } finally {
      setSaving(false);
    }
  }

  async function updateRole() {
    if (!selectedRoleId || !roleName.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/administration/roles/${selectedRoleId}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: roleName.trim(), color: roleColor, permissions: rolePermissions }) });
      if (!response.ok) throw new Error("Failed to update role");
      await fetchAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update role");
    } finally {
      setSaving(false);
    }
  }

  async function deleteRole() {
    if (!selectedRoleId) return;
    setSaving(true);
    setError(null);
    try {
      const response = await fetch(`/api/administration/roles/${selectedRoleId}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Failed to delete role");
      setSelectedRoleId(null);
      setRoleName("");
      setRoleColor("#3B4A61");
      setRolePermissions({});
      await fetchAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete role");
    } finally {
      setSaving(false);
    }
  }

  async function generateInsight() {
    setInsightLoading(true);
    try {
      const response = await fetch("/api/administration/insights", { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to generate AI insight");
      const data = (await response.json()) as AdminInsight;
      setInsight(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate AI insight");
    } finally {
      setInsightLoading(false);
    }
  }

  if (loading) return <div className="p-6 text-sm text-gray-500">Loading administration...</div>;

  return (
    <div className="flex h-full">
      <aside className="w-60 shrink-0 border-r bg-white p-3">
        <div className="mb-3 px-2"><p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Administration</p></div>
        {[{ id: "overview", label: "Overview", icon: LayoutDashboard }, { id: "users", label: "Users & Access", icon: Users }, { id: "roles", label: "Roles", icon: Shield }, { id: "settings", label: "Settings", icon: Palette }, { id: "modules", label: "Modules", icon: Blocks }, { id: "security", label: "Security", icon: KeyRound }, { id: "reports", label: "Reports", icon: BarChart3 }, { id: "logs", label: "Audit Logs", icon: FileClock }].map((item) => (
          <button key={item.id} onClick={() => setSection(item.id as typeof section)} className={cn("mb-1 flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm", section === item.id ? "bg-[#FE0000]/10 text-[#FE0000]" : "text-slate-600 hover:bg-slate-100")}><item.icon className="h-4 w-4" />{item.label}</button>
        ))}
        <Button variant="outline" size="sm" className="mt-2 w-full" onClick={() => void fetchAll()}><RefreshCw className="mr-1.5 h-3.5 w-3.5" />Refresh</Button>
      </aside>
      <section className="flex min-h-0 flex-1 flex-col">
        <div className="border-b bg-white px-5 py-3">
          <h1 className="text-xl font-semibold">Administration Control Center</h1>
          <p className="text-sm text-slate-500">Configure branding, module availability, access model, analytics, and governance logs.</p>
          {error ? <p className="mt-2 text-sm text-red-600">{error}</p> : null}
          {!canManage ? <p className="mt-2 text-sm text-amber-700">Read-only mode: administration.manage permission required for changes.</p> : null}
        </div>
        <div className="min-h-0 flex-1 overflow-auto p-5">
          {section === "overview" ? (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-4">
                <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Users</p><p className="text-2xl font-semibold">{users.length}</p></CardContent></Card>
                <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Active Users</p><p className="text-2xl font-semibold">{users.filter((u) => u.isActive).length}</p></CardContent></Card>
                <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Roles</p><p className="text-2xl font-semibold">{roles.length}</p></CardContent></Card>
                <Card><CardContent className="p-4"><p className="text-xs text-slate-500">Enabled Modules</p><p className="text-2xl font-semibold">{moduleToggles.filter((module) => module.enabled).length}</p></CardContent></Card>
              </div>
              <Card><CardHeader><CardTitle className="flex items-center justify-between text-sm"><span className="inline-flex items-center gap-2"><Sparkles className="h-4 w-4 text-[#FE0000]" />AI Insight</span><Button size="sm" variant="outline" onClick={() => void generateInsight()} disabled={insightLoading}>{insightLoading ? "Analyzing..." : "Generate"}</Button></CardTitle></CardHeader><CardContent className="text-sm">{!insight ? <p className="text-slate-500">Generate AI governance summary for current state.</p> : <><p>{insight.summary}</p><p className="mt-2 text-xs text-slate-400">Generated: {formatDateTime(insight.generatedAt, timezone)} ({timezone})</p></>}</CardContent></Card>
            </div>
          ) : null}

          {section === "settings" ? (
            <Card><CardHeader><CardTitle className="text-sm">Software & Theme Settings</CardTitle></CardHeader><CardContent className="space-y-3"><div className="grid gap-3 sm:grid-cols-2"><Input value={settingsForm.appName} onChange={(e) => setSettingsForm((prev) => ({ ...prev, appName: e.target.value }))} placeholder="Software name" /><Input value={settingsForm.appTagline} onChange={(e) => setSettingsForm((prev) => ({ ...prev, appTagline: e.target.value }))} placeholder="Tagline" /><Input value={settingsForm.supportEmail} onChange={(e) => setSettingsForm((prev) => ({ ...prev, supportEmail: e.target.value }))} placeholder="Support email" /><Input value={settingsForm.defaultTimezone} onChange={(e) => setSettingsForm((prev) => ({ ...prev, defaultTimezone: e.target.value }))} placeholder="Default timezone (e.g. Asia/Dubai)" /><Input value={settingsForm.aiModel} onChange={(e) => setSettingsForm((prev) => ({ ...prev, aiModel: e.target.value }))} placeholder="AI model" /></div><div className="rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600">Time preview ({settingsForm.defaultTimezone || "UTC"}): {formatDateTime(new Date().toISOString(), settingsForm.defaultTimezone || "UTC")}</div><div className="grid gap-3 sm:grid-cols-4"><Input value={settingsForm.themePrimary} onChange={(e) => setSettingsForm((prev) => ({ ...prev, themePrimary: e.target.value }))} placeholder="Primary" /><Input value={settingsForm.sidebarFrom} onChange={(e) => setSettingsForm((prev) => ({ ...prev, sidebarFrom: e.target.value }))} placeholder="Sidebar from" /><Input value={settingsForm.sidebarMid} onChange={(e) => setSettingsForm((prev) => ({ ...prev, sidebarMid: e.target.value }))} placeholder="Sidebar mid" /><Input value={settingsForm.sidebarTo} onChange={(e) => setSettingsForm((prev) => ({ ...prev, sidebarTo: e.target.value }))} placeholder="Sidebar to" /><Input value={settingsForm.topbarFrom} onChange={(e) => setSettingsForm((prev) => ({ ...prev, topbarFrom: e.target.value }))} placeholder="Topbar from" /><Input value={settingsForm.topbarMid} onChange={(e) => setSettingsForm((prev) => ({ ...prev, topbarMid: e.target.value }))} placeholder="Topbar mid" /><Input value={settingsForm.topbarTo} onChange={(e) => setSettingsForm((prev) => ({ ...prev, topbarTo: e.target.value }))} placeholder="Topbar to" /><Input value={settingsForm.topbarAccent} onChange={(e) => setSettingsForm((prev) => ({ ...prev, topbarAccent: e.target.value }))} placeholder="Topbar accent" /></div><div className="flex gap-2"><Button size="sm" onClick={() => void saveSettings()} disabled={!canManage || saving}><Save className="mr-1.5 h-3.5 w-3.5" />Save</Button><Button size="sm" variant="outline" onClick={() => applyRuntimeTheme(settingsForm)}>Preview</Button></div></CardContent></Card>
          ) : null}

          {section === "modules" ? (
            <Card><CardHeader><CardTitle className="text-sm">Module Toggles</CardTitle></CardHeader><CardContent className="space-y-2">{moduleToggles.map((moduleItem) => (<label key={moduleItem.id} className="flex items-center justify-between rounded-md border px-3 py-2"><span className="text-sm">{moduleLabels[moduleItem.id]}</span><div className="flex items-center gap-2">{moduleItem.locked ? <Badge variant="outline" className="text-xs">Locked</Badge> : null}<input type="checkbox" checked={moduleItem.enabled} disabled={!canManage || moduleItem.locked} onChange={(e) => setModuleToggles((prev) => prev.map((item) => item.id === moduleItem.id ? { ...item, enabled: e.target.checked } : item))} /></div></label>))}<Button size="sm" onClick={() => void saveModuleToggles()} disabled={!canManage || saving}><Save className="mr-1.5 h-3.5 w-3.5" />Save Module Toggles</Button></CardContent></Card>
          ) : null}

          {section === "users" ? (
            <div className="grid gap-4 lg:grid-cols-[340px_minmax(0,1fr)]">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-sm">
                    <span>Users</span>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 px-2 text-xs"
                      onClick={() => setCreateUserOpen(true)}
                      disabled={!canManage}
                    >
                      <UserPlus className="mr-1.5 h-3.5 w-3.5" />
                      Add User
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Input value={userSearch} onChange={(e) => setUserSearch(e.target.value)} placeholder="Search users..." />
                  <div className="flex items-center justify-between rounded-md border bg-slate-50 px-2.5 py-1.5 text-xs text-slate-600">
                    <span className="inline-flex items-center gap-1.5">
                      <Building2 className="h-3.5 w-3.5" />
                      Departments: {departments.length}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-[11px]"
                      onClick={openDepartmentDialog}
                      disabled={!canManage}
                    >
                      Manage
                    </Button>
                  </div>
                  <ScrollArea className="h-[520px]">
                    {filteredUsers.map((user) => (
                      <button
                        key={user.id}
                        onClick={() => {
                          setSelectedUserId(user.id);
                          setSelectedUserRoleIds(user.roles.map((role) => role.id));
                        }}
                        className={cn(
                          "mb-1 w-full rounded-md border px-3 py-2 text-left",
                          selectedUserId === user.id ? "border-[#FE0000]/20 bg-[#FE0000]/10" : "hover:bg-slate-50"
                        )}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <p className="truncate text-sm font-medium">{user.fullname || `${user.name} ${user.surname}`.trim()}</p>
                          <Badge variant={user.isActive ? "secondary" : "outline"} className="text-[10px]">
                            {user.isActive ? "Active" : "Disabled"}
                          </Badge>
                        </div>
                        <p className="truncate text-xs text-slate-500">{user.login} - {user.department || "-"}</p>
                      </button>
                    ))}
                  </ScrollArea>
                </CardContent>
              </Card>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">User Management</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {!selectedUser ? (
                      <p className="text-sm text-slate-500">Select a user.</p>
                    ) : (
                      <>
                        <div className="rounded-md border bg-slate-50 p-3">
                          <p className="text-sm font-medium">{selectedUser.fullname || `${selectedUser.name} ${selectedUser.surname}`.trim()}</p>
                          <p className="text-xs text-slate-600">{selectedUser.email}</p>
                          <p className="mt-1 text-xs text-slate-500">
                            Last activity: {formatDateTime(selectedUser.lastActivity ?? null, timezone)}
                          </p>
                          <p className="text-xs text-slate-500">
                            Joined: {formatDateTime(selectedUser.createdAt ?? null, timezone)}
                          </p>
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          <Button
                            size="sm"
                            variant={selectedUser.isActive ? "destructive" : "default"}
                            onClick={() => void updateSelectedUser({ isActive: !selectedUser.isActive })}
                            disabled={!canManage || userActionSaving}
                          >
                            {selectedUser.isActive ? "Disable User" : "Enable User"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => void updateSelectedUser({ isAdmin: !selectedUser.isAdmin })}
                            disabled={!canManage || userActionSaving}
                          >
                            {selectedUser.isAdmin ? "Remove Admin" : "Make Admin"}
                          </Button>
                          <select
                            className="h-9 rounded-md border px-2 text-sm"
                            value={String(selectedUser.workState ?? 1)}
                            disabled={!canManage || userActionSaving}
                            onChange={(event) => {
                              const nextWorkState = Number(event.target.value);
                              if (Number.isFinite(nextWorkState)) void updateSelectedUser({ workState: nextWorkState });
                            }}
                          >
                            <option value="1">Work State: Available</option>
                            <option value="2">Work State: Away</option>
                            <option value="0">Work State: Offline</option>
                          </select>
                          <select
                            className="h-9 min-w-[180px] rounded-md border px-2 text-sm"
                            value={selectedUser.department || ""}
                            disabled={!canManage || userActionSaving}
                            onChange={(event) => void updateSelectedUser({ department: event.target.value })}
                          >
                            <option value="">Department: Unassigned</option>
                            {departments
                              .filter((department) => department.isActive || department.name === selectedUser.department)
                              .map((department) => (
                                <option key={`dept-user-${department.id}`} value={department.name}>
                                  Department: {department.name}
                                </option>
                              ))}
                          </select>
                        </div>

                        <div className="rounded-md border p-3">
                          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Change Password</p>
                          <div className="flex flex-wrap gap-2">
                            <Input
                              type="text"
                              placeholder="New password (min 8 chars)"
                              value={userPassword}
                              onChange={(event) => setUserPassword(event.target.value)}
                              className="min-w-[260px] flex-1"
                              disabled={!canManage || userActionSaving}
                            />
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setUserPassword(generateStrongPassword())}
                              disabled={!canManage || userActionSaving}
                            >
                              <KeyRound className="mr-1.5 h-3.5 w-3.5" />
                              Generate
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => void saveSelectedUserPassword()}
                              disabled={!canManage || userActionSaving || userPassword.trim().length < 8}
                            >
                              Update Password
                            </Button>
                          </div>
                        </div>

                        <div className="rounded-md border p-3">
                          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Two-step Verification</p>
                          {userTwoFactorLoading ? (
                            <p className="text-xs text-slate-500">Loading 2-step status...</p>
                          ) : (
                            <>
                              <div className="flex flex-wrap items-center gap-2">
                                <Badge variant={selectedUserTwoFactor?.enabled ? "secondary" : "outline"} className="text-xs">
                                  {selectedUserTwoFactor?.enabled ? "Enabled" : "Disabled"}
                                </Badge>
                                <span className="text-xs text-slate-500">
                                  Backup codes left: {selectedUserTwoFactor?.backupCodesRemaining ?? 0}
                                </span>
                              </div>
                              <div className="mt-2 flex flex-wrap gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => void manageSelectedUserTwoFactor("enable")}
                                  disabled={!canManage || userTwoFactorSaving}
                                >
                                  Enable
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => void manageSelectedUserTwoFactor("rotate")}
                                  disabled={!canManage || userTwoFactorSaving || !selectedUserTwoFactor?.enabled}
                                >
                                  Rotate Secret
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => void manageSelectedUserTwoFactor("backup")}
                                  disabled={!canManage || userTwoFactorSaving || !selectedUserTwoFactor?.enabled}
                                >
                                  New Backup Codes
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => void manageSelectedUserTwoFactor("disable")}
                                  disabled={!canManage || userTwoFactorSaving || !selectedUserTwoFactor?.enabled}
                                >
                                  Disable
                                </Button>
                              </div>
                              {userTwoFactorSetup ? (
                                <div className="mt-3 rounded-md border bg-slate-50 p-3">
                                  <p className="text-xs font-semibold text-slate-700">Google Authenticator Setup (share securely)</p>
                                  <p className="mt-1 text-xs text-slate-600">
                                    Open Google Authenticator, tap <span className="font-medium">+</span>, then scan QR or enter setup key manually.
                                  </p>
                                  <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-start">
                                    <div className="rounded-md border bg-white p-2">
                                      <img
                                        src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(userTwoFactorSetup.otpAuthUri)}`}
                                        alt="Google Authenticator QR"
                                        className="h-[180px] w-[180px]"
                                      />
                                    </div>
                                    <div className="min-w-0 flex-1 space-y-2">
                                      <p className="break-all text-xs text-slate-600">Secret: {userTwoFactorSetup.secret}</p>
                                      <div className="flex flex-wrap gap-2">
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={async () => {
                                            try {
                                              await navigator.clipboard.writeText(userTwoFactorSetup.secret);
                                            } catch {
                                              setError("Unable to copy secret. Please copy manually.");
                                            }
                                          }}
                                        >
                                          Copy Secret
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={async () => {
                                            try {
                                              await navigator.clipboard.writeText(userTwoFactorSetup.otpAuthUri);
                                            } catch {
                                              setError("Unable to copy OTP URI. Please copy manually.");
                                            }
                                          }}
                                        >
                                          Copy OTP URI
                                        </Button>
                                      </div>
                                    </div>
                                  </div>
                                  {userTwoFactorSetup.backupCodes.length > 0 ? (
                                    <div className="mt-2 grid gap-1 sm:grid-cols-2">
                                      {userTwoFactorSetup.backupCodes.map((code) => (
                                        <code key={code} className="rounded border bg-white px-2 py-1 text-[11px] text-slate-700">{code}</code>
                                      ))}
                                    </div>
                                  ) : null}
                                </div>
                              ) : null}
                            </>
                          )}
                        </div>

                        <div className="rounded-md border p-3">
                          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Role Assignment</p>
                          <div className="space-y-1">
                            {roles.map((role) => (
                              <label key={role.id} className="flex items-center justify-between rounded border px-2 py-1.5 text-sm">
                                <span>{role.name}</span>
                                <input
                                  type="checkbox"
                                  checked={selectedUserRoleIds.includes(role.id)}
                                  disabled={!canManage}
                                  onChange={(e) =>
                                    setSelectedUserRoleIds((prev) =>
                                      e.target.checked ? Array.from(new Set([...prev, role.id])) : prev.filter((id) => id !== role.id)
                                    )
                                  }
                                />
                              </label>
                            ))}
                          </div>
                          <Button size="sm" variant="outline" className="mt-2" onClick={() => void saveUserRoles()} disabled={!canManage || saving}>
                            Save Roles
                          </Button>
                        </div>

                        <div className="rounded-md border p-3">
                          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Direct Permissions</p>
                          <div className="max-h-56 overflow-auto border">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>Module</TableHead>
                                  <TableHead>R</TableHead>
                                  <TableHead>W</TableHead>
                                  <TableHead>M</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {moduleIds.map((moduleId) => (
                                  <TableRow key={moduleId}>
                                    <TableCell className="text-xs">{moduleLabels[moduleId]}</TableCell>
                                    {actions.map((action) => (
                                      <TableCell key={`${moduleId}-${action}`}>
                                        <input
                                          type="checkbox"
                                          checked={(selectedUserGrants[moduleId] ?? []).includes(action)}
                                          disabled={!canManage}
                                          onChange={(e) => {
                                            const next = clonePermissions(selectedUserGrants);
                                            applyAction(next, moduleId, action, e.target.checked);
                                            setSelectedUserGrants(next);
                                          }}
                                        />
                                      </TableCell>
                                    ))}
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                          <Button size="sm" className="mt-2" onClick={() => void saveUserGrants()} disabled={!canManage || saving}>
                            Save Direct Permissions
                          </Button>
                        </div>

                        <div className="rounded-md border p-3">
                          <div className="mb-2 flex items-center justify-between">
                            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">User Logs</p>
                            <Button size="sm" variant="outline" onClick={() => selectedUserId && void loadUserLogs(selectedUserId)} disabled={userLogsLoading}>
                              <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
                              Refresh
                            </Button>
                          </div>
                          <div className="max-h-52 overflow-auto border">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>Time</TableHead>
                                  <TableHead>Action</TableHead>
                                  <TableHead>Module</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {userLogsLoading ? (
                                  <TableRow>
                                    <TableCell className="text-xs text-slate-500" colSpan={3}>
                                      Loading logs...
                                    </TableCell>
                                  </TableRow>
                                ) : userLogs.length === 0 ? (
                                  <TableRow>
                                    <TableCell className="text-xs text-slate-500" colSpan={3}>
                                      No logs found.
                                    </TableCell>
                                  </TableRow>
                                ) : (
                                  userLogs.map((log) => (
                                    <TableRow key={log.id}>
                                      <TableCell className="text-xs">{formatDateTime(log.createdAt, timezone)}</TableCell>
                                      <TableCell className="text-xs">{log.action}</TableCell>
                                      <TableCell className="text-xs">{log.module}</TableCell>
                                    </TableRow>
                                  ))
                                )}
                              </TableBody>
                            </Table>
                          </div>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : null}

          {section === "roles" ? (
            <div className="grid gap-4 lg:grid-cols-2"><Card><CardHeader><CardTitle className="text-sm">Roles</CardTitle></CardHeader><CardContent className="space-y-1">{roles.map((role) => (<button key={role.id} onClick={() => { setSelectedRoleId(role.id); setRoleName(role.name); setRoleColor(role.color); setRolePermissions(clonePermissions(role.permissions)); }} className={cn("w-full rounded-md border px-3 py-2 text-left", selectedRoleId === role.id ? "border-[#FE0000]/30 bg-[#FE0000]/10" : "hover:bg-slate-50")}><p className="text-sm font-medium">{role.name}</p><p className="text-xs text-slate-500">{role.memberCount} members</p></button>))}</CardContent></Card><Card><CardHeader><CardTitle className="text-sm">Role Editor</CardTitle></CardHeader><CardContent className="space-y-3"><Input value={roleName} onChange={(e) => setRoleName(e.target.value)} placeholder="Role name" /><Input value={roleColor} onChange={(e) => setRoleColor(e.target.value)} placeholder="#3B4A61" /><div className="max-h-64 overflow-auto border"><Table><TableHeader><TableRow><TableHead>Module</TableHead><TableHead>R</TableHead><TableHead>W</TableHead><TableHead>M</TableHead></TableRow></TableHeader><TableBody>{moduleIds.map((moduleId) => (<TableRow key={`role-${moduleId}`}><TableCell className="text-xs">{moduleLabels[moduleId]}</TableCell>{actions.map((action) => (<TableCell key={`role-${moduleId}-${action}`}><input type="checkbox" checked={(rolePermissions[moduleId] ?? []).includes(action)} disabled={!canManage} onChange={(e) => { const next = clonePermissions(rolePermissions); applyAction(next, moduleId, action, e.target.checked); setRolePermissions(next); }} /></TableCell>))}</TableRow>))}</TableBody></Table></div><div className="flex gap-2"><Button size="sm" onClick={() => void createRole()} disabled={!canManage || saving}>Create</Button><Button size="sm" variant="outline" onClick={() => void updateRole()} disabled={!canManage || saving || !selectedRoleId}>Update</Button><Button size="sm" variant="destructive" onClick={() => void deleteRole()} disabled={!canManage || saving || !selectedRoleId}>Delete</Button></div></CardContent></Card></div>
          ) : null}

          {section === "security" ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Security Policy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="ip-allowlist">IP Allowlist</Label>
                    <Textarea
                      id="ip-allowlist"
                      rows={5}
                      placeholder="One IP/CIDR per line"
                      value={securityForm.ipAllowlistText}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, ipAllowlistText: event.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="ip-blocklist">IP Blocklist</Label>
                    <Textarea
                      id="ip-blocklist"
                      rows={5}
                      placeholder="One IP/CIDR per line"
                      value={securityForm.ipBlocklistText}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, ipBlocklistText: event.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="country-allowlist">Country Allowlist (ISO)</Label>
                    <Textarea
                      id="country-allowlist"
                      rows={4}
                      placeholder="US, AE, IN..."
                      value={securityForm.countryAllowlistText}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, countryAllowlistText: event.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="country-blocklist">Country Blocklist (ISO)</Label>
                    <Textarea
                      id="country-blocklist"
                      rows={4}
                      placeholder="US, AE, IN..."
                      value={securityForm.countryBlocklistText}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, countryBlocklistText: event.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="rate-max">Login Max Attempts</Label>
                    <Input
                      id="rate-max"
                      type="number"
                      min={1}
                      max={50}
                      value={securityForm.rateMaxAttempts}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, rateMaxAttempts: Number(event.target.value) }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="rate-window">Rate Window (minutes)</Label>
                    <Input
                      id="rate-window"
                      type="number"
                      min={1}
                      max={120}
                      value={securityForm.rateWindowMinutes}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, rateWindowMinutes: Number(event.target.value) }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="rate-lock">Lock Duration (minutes)</Label>
                    <Input
                      id="rate-lock"
                      type="number"
                      min={1}
                      max={240}
                      value={securityForm.rateLockMinutes}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, rateLockMinutes: Number(event.target.value) }))}
                    />
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="pwd-min">Min Password Length</Label>
                    <Input
                      id="pwd-min"
                      type="number"
                      min={8}
                      max={128}
                      value={securityForm.minPasswordLength}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, minPasswordLength: Number(event.target.value) }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="session-max">Session Max (minutes)</Label>
                    <Input
                      id="session-max"
                      type="number"
                      min={15}
                      max={43200}
                      value={securityForm.sessionMaxMinutes}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, sessionMaxMinutes: Number(event.target.value) }))}
                    />
                  </div>
                </div>

                <div className="flex flex-wrap gap-4 rounded-md border p-3">
                  <label className="inline-flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={securityForm.requireUpper}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, requireUpper: event.target.checked }))}
                    />
                    Require uppercase
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={securityForm.requireLower}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, requireLower: event.target.checked }))}
                    />
                    Require lowercase
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={securityForm.requireNumber}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, requireNumber: event.target.checked }))}
                    />
                    Require number
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={securityForm.requireSymbol}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, requireSymbol: event.target.checked }))}
                    />
                    Require symbol
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={securityForm.enforce2FAForAdmins}
                      onChange={(event) => setSecurityForm((prev) => ({ ...prev, enforce2FAForAdmins: event.target.checked }))}
                    />
                    Enforce 2FA for admins
                  </label>
                </div>

                <Button size="sm" onClick={() => void saveSecurityPolicy()} disabled={!canManage || securitySaving}>
                  <Save className="mr-1.5 h-3.5 w-3.5" />
                  {securitySaving ? "Saving..." : "Save Security Policy"}
                </Button>
              </CardContent>
            </Card>
          ) : null}

          {section === "reports" ? (
            <Card><CardHeader><CardTitle className="flex items-center justify-between text-sm"><span>Module Reports & Employee Review</span><div className="flex items-center gap-2"><select className="h-8 rounded-md border px-2 text-xs" value={reportDays} onChange={(e) => setReportDays(Number(e.target.value))}><option value={14}>Last 14 days</option><option value={30}>Last 30 days</option><option value={60}>Last 60 days</option><option value={90}>Last 90 days</option></select><Button size="sm" variant="outline" onClick={() => void loadReports()} disabled={reportsLoading}><RefreshCw className="mr-1.5 h-3.5 w-3.5" />{reportsLoading ? "Loading..." : "Refresh"}</Button><Button size="sm" onClick={() => void loadReports(true)} disabled={reportsInsightLoading}><Sparkles className="mr-1.5 h-3.5 w-3.5" />{reportsInsightLoading ? "Analyzing..." : "AI Summary"}</Button></div></CardTitle></CardHeader><CardContent className="space-y-4">{!reports ? <p className="text-sm text-slate-500">Loading report data...</p> : <><div className="grid gap-3 sm:grid-cols-6"><Card><CardContent className="p-3"><p className="text-[11px] text-slate-500">Users</p><p className="text-lg font-semibold">{reports.totals.users}</p></CardContent></Card><Card><CardContent className="p-3"><p className="text-[11px] text-slate-500">Active Users</p><p className="text-lg font-semibold">{reports.totals.activeUsers}</p></CardContent></Card><Card><CardContent className="p-3"><p className="text-[11px] text-slate-500">Unread Emails</p><p className="text-lg font-semibold">{reports.totals.unreadEmails}</p></CardContent></Card><Card><CardContent className="p-3"><p className="text-[11px] text-slate-500">Open Requests</p><p className="text-lg font-semibold">{reports.totals.openServiceRequests}</p></CardContent></Card><Card><CardContent className="p-3"><p className="text-[11px] text-slate-500">Sent Emails</p><p className="text-lg font-semibold">{reports.totals.sentEmails}</p></CardContent></Card><Card><CardContent className="p-3"><p className="text-[11px] text-slate-500">Audit Events</p><p className="text-lg font-semibold">{reports.totals.auditEvents}</p></CardContent></Card></div><p className="text-xs text-slate-500">Generated: {formatDateTime(reports.generatedAt, reports.timezone)} ({reports.timezone})</p><div className="overflow-auto rounded-md border"><Table><TableHeader><TableRow><TableHead>Module</TableHead><TableHead>Total</TableHead><TableHead>Recent</TableHead><TableHead>Backlog</TableHead><TableHead>Trend</TableHead></TableRow></TableHeader><TableBody>{reports.modules.map((moduleRow) => (<TableRow key={moduleRow.moduleId}><TableCell className="text-xs font-medium">{moduleRow.label}</TableCell><TableCell className="text-xs">{moduleRow.total}</TableCell><TableCell className="text-xs">{moduleRow.recent}</TableCell><TableCell className="text-xs">{moduleRow.backlog}</TableCell><TableCell className="text-xs"><Badge variant="outline" className={cn(moduleRow.trend === "up" && "border-emerald-300 text-emerald-700", moduleRow.trend === "down" && "border-amber-300 text-amber-700")}>{moduleRow.trend}</Badge></TableCell></TableRow>))}</TableBody></Table></div><div className="overflow-auto rounded-md border"><Table><TableHeader><TableRow><TableHead>Employee</TableHead><TableHead>Department</TableHead><TableHead>Score</TableHead><TableHead>Tasks</TableHead><TableHead>Tickets</TableHead><TableHead>Emails Sent</TableHead><TableHead>Last Activity</TableHead></TableRow></TableHeader><TableBody>{reports.employees.slice(0, 25).map((employee) => (<TableRow key={employee.userId}><TableCell className="text-xs"><div className="font-medium">{employee.name}</div><div className="text-[11px] text-slate-500">{employee.email}</div></TableCell><TableCell className="text-xs">{employee.department || "-"}</TableCell><TableCell className="text-xs"><Badge variant="outline" className={cn(employee.activityScore >= 75 && "border-emerald-300 text-emerald-700", employee.activityScore < 45 && "border-rose-300 text-rose-700")}>{employee.activityScore}</Badge></TableCell><TableCell className="text-xs">{employee.tasksCompleted}/{employee.tasksAssigned}{employee.tasksOverdue > 0 ? ` (${employee.tasksOverdue} overdue)` : ""}</TableCell><TableCell className="text-xs">{employee.ticketsClosed}/{employee.ticketsAssigned}</TableCell><TableCell className="text-xs">{employee.emailsSent}</TableCell><TableCell className="text-xs">{formatDateTime(employee.lastActivity, reports.timezone)}</TableCell></TableRow>))}</TableBody></Table></div>{reports.insight ? <Card className="border-[#FE0000]/20 bg-[#FE0000]/5"><CardHeader><CardTitle className="text-sm">AI Report Summary</CardTitle></CardHeader><CardContent className="space-y-2 text-sm"><p>{reports.insight.summary}</p>{reports.insight.highlights.length > 0 ? <div><p className="text-xs font-semibold uppercase text-slate-500">Highlights</p><ul className="mt-1 space-y-1 text-xs text-slate-700">{reports.insight.highlights.map((item, idx) => (<li key={`h-${idx}`}>- {item}</li>))}</ul></div> : null}{reports.insight.risks.length > 0 ? <div><p className="text-xs font-semibold uppercase text-slate-500">Risks</p><ul className="mt-1 space-y-1 text-xs text-slate-700">{reports.insight.risks.map((item, idx) => (<li key={`r-${idx}`}>- {item}</li>))}</ul></div> : null}{reports.insight.actions.length > 0 ? <div><p className="text-xs font-semibold uppercase text-slate-500">Actions</p><ul className="mt-1 space-y-1 text-xs text-slate-700">{reports.insight.actions.map((item, idx) => (<li key={`a-${idx}`}>- {item}</li>))}</ul></div> : null}</CardContent></Card> : null}</>}</CardContent></Card>
          ) : null}

          {section === "logs" ? (
            <Card><CardHeader><CardTitle className="text-sm">Audit Logs ({logs.length})</CardTitle></CardHeader><CardContent><Button size="sm" variant="outline" onClick={() => void loadLogs()}><RefreshCw className="mr-1.5 h-3.5 w-3.5" />Refresh</Button><div className="mt-3 max-h-[420px] overflow-auto border"><Table><TableHeader><TableRow><TableHead>Time</TableHead><TableHead>User</TableHead><TableHead>Action</TableHead><TableHead>Module</TableHead><TableHead>Details</TableHead></TableRow></TableHeader><TableBody>{logs.map((log) => (<TableRow key={log.id}><TableCell className="text-xs">{formatDateTime(log.createdAt, settingsForm.defaultTimezone)}</TableCell><TableCell className="text-xs">{log.user?.name ?? "System"}</TableCell><TableCell><Badge variant="secondary" className="text-xs">{log.action}</Badge></TableCell><TableCell className="text-xs">{log.module}</TableCell><TableCell className="text-xs">{log.details || "-"}</TableCell></TableRow>))}</TableBody></Table></div></CardContent></Card>
          ) : null}
        </div>

        <Dialog open={departmentDialogOpen} onOpenChange={(open) => { if (!departmentSaving) setDepartmentDialogOpen(open); }}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-[#FE0000]" />
                Department Management
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-3 py-1">
              <div className="flex items-center gap-2">
                <Input
                  value={departmentNameInput}
                  onChange={(event) => setDepartmentNameInput(event.target.value)}
                  placeholder="Add new department..."
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      addDepartmentToDraft();
                    }
                  }}
                />
                <Button type="button" variant="outline" onClick={addDepartmentToDraft}>
                  Add
                </Button>
              </div>

              <div className="max-h-[340px] overflow-auto rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead className="w-24">Status</TableHead>
                      <TableHead className="w-20 text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {departmentDraft.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={3} className="text-xs text-slate-500">
                          No departments yet.
                        </TableCell>
                      </TableRow>
                    ) : (
                      departmentDraft
                        .sort((a, b) => a.name.localeCompare(b.name))
                        .map((department) => (
                          <TableRow key={`dept-draft-${department.id}`}>
                            <TableCell>
                              <Input
                                value={department.name}
                                onChange={(event) =>
                                  setDepartmentDraft((prev) =>
                                    prev.map((item) =>
                                      item.id === department.id
                                        ? { ...item, name: event.target.value }
                                        : item
                                    )
                                  )
                                }
                                className="h-8"
                              />
                            </TableCell>
                            <TableCell>
                              <label className="inline-flex items-center gap-2 text-xs text-slate-600">
                                <input
                                  type="checkbox"
                                  checked={department.isActive}
                                  onChange={(event) =>
                                    setDepartmentDraft((prev) =>
                                      prev.map((item) =>
                                        item.id === department.id
                                          ? { ...item, isActive: event.target.checked, updatedAt: new Date().toISOString() }
                                          : item
                                      )
                                    )
                                  }
                                />
                                {department.isActive ? "Active" : "Inactive"}
                              </label>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                type="button"
                                size="sm"
                                variant="ghost"
                                className="h-8 px-2 text-red-600 hover:text-red-700"
                                onClick={() =>
                                  setDepartmentDraft((prev) => prev.filter((item) => item.id !== department.id))
                                }
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                    )}
                  </TableBody>
                </Table>
              </div>
              <p className="text-xs text-slate-500">
                Inactive departments stay in history but are hidden from new user assignment.
              </p>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  if (!departmentSaving) {
                    setDepartmentDialogOpen(false);
                    setDepartmentDraft([]);
                    setDepartmentNameInput("");
                  }
                }}
                disabled={departmentSaving}
              >
                Cancel
              </Button>
              <Button
                type="button"
                style={{ backgroundColor: "#FE0000", color: "#fff" }}
                onClick={() => void saveDepartments()}
                disabled={!canManage || departmentSaving}
              >
                {departmentSaving ? "Saving..." : "Save Departments"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog
          open={createUserOpen}
          onOpenChange={(open) => {
            setCreateUserOpen(open);
            if (!open && !createUserSaving) {
              setNewUserForm(EMPTY_NEW_USER_FORM);
            }
          }}
        >
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
            </DialogHeader>

            <div className="space-y-4 py-1">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="new-user-login">Login *</Label>
                  <Input
                    id="new-user-login"
                    value={newUserForm.login}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, login: event.target.value }))}
                    placeholder="john.doe"
                    autoFocus
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="new-user-email">Email *</Label>
                  <Input
                    id="new-user-email"
                    type="email"
                    value={newUserForm.email}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, email: event.target.value }))}
                    placeholder="john@example.com"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="new-user-name">First Name *</Label>
                  <Input
                    id="new-user-name"
                    value={newUserForm.name}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, name: event.target.value }))}
                    placeholder="John"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="new-user-surname">Last Name</Label>
                  <Input
                    id="new-user-surname"
                    value={newUserForm.surname}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, surname: event.target.value }))}
                    placeholder="Doe"
                  />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="new-user-fullname">Display Name</Label>
                  <Input
                    id="new-user-fullname"
                    value={newUserForm.fullname}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, fullname: event.target.value }))}
                    placeholder="John Doe"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="new-user-position">Position</Label>
                  <Input
                    id="new-user-position"
                    value={newUserForm.position}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, position: event.target.value }))}
                    placeholder="Team Lead"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="new-user-department">Department</Label>
                  <div className="flex gap-2">
                    <Input
                      id="new-user-department"
                      list="department-options"
                      value={newUserForm.department}
                      onChange={(event) => setNewUserForm((prev) => ({ ...prev, department: event.target.value }))}
                      placeholder="Operations"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      className="shrink-0"
                      onClick={openDepartmentDialog}
                      disabled={!canManage}
                    >
                      Manage
                    </Button>
                  </div>
                  <datalist id="department-options">
                    {departments
                      .filter((department) => department.isActive)
                      .map((department) => (
                        <option key={`dept-option-${department.id}`} value={department.name} />
                      ))}
                  </datalist>
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="new-user-password">Password *</Label>
                  <div className="flex gap-2">
                    <Input
                      id="new-user-password"
                      type="text"
                      value={newUserForm.password}
                      onChange={(event) => setNewUserForm((prev) => ({ ...prev, password: event.target.value }))}
                      placeholder="At least 8 characters"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setNewUserForm((prev) => ({ ...prev, password: generateStrongPassword() }))}
                    >
                      <KeyRound className="mr-1.5 h-3.5 w-3.5" />
                      Generate
                    </Button>
                  </div>
                </div>
              </div>

              <div className="rounded-md border p-3">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Initial Roles</p>
                {roles.length === 0 ? (
                  <p className="text-xs text-slate-500">No roles available yet.</p>
                ) : (
                  <div className="grid gap-1 sm:grid-cols-2">
                    {roles.map((role) => (
                      <label key={`new-role-${role.id}`} className="flex items-center justify-between rounded border px-2 py-1.5 text-sm">
                        <span>{role.name}</span>
                        <input
                          type="checkbox"
                          checked={newUserForm.roleIds.includes(role.id)}
                          onChange={(event) =>
                            setNewUserForm((prev) => ({
                              ...prev,
                              roleIds: event.target.checked
                                ? Array.from(new Set([...prev.roleIds, role.id]))
                                : prev.roleIds.filter((id) => id !== role.id),
                            }))
                          }
                        />
                      </label>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-4 rounded-md border p-3">
                <label className="inline-flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={newUserForm.isActive}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, isActive: event.target.checked }))}
                  />
                  Active user
                </label>
                <label className="inline-flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={newUserForm.isAdmin}
                    onChange={(event) => setNewUserForm((prev) => ({ ...prev, isAdmin: event.target.checked }))}
                  />
                  Administrator
                </label>
              </div>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setCreateUserOpen(false);
                  setNewUserForm(EMPTY_NEW_USER_FORM);
                }}
                disabled={createUserSaving}
              >
                Cancel
              </Button>
              <Button
                type="button"
                style={{ backgroundColor: "#FE0000", color: "#fff" }}
                onClick={() => void createUser()}
                disabled={
                  !canManage ||
                  createUserSaving ||
                  !newUserForm.login.trim() ||
                  !newUserForm.email.trim() ||
                  !newUserForm.name.trim() ||
                  newUserForm.password.trim().length < 8
                }
              >
                {createUserSaving ? "Creating..." : "Create User"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </section>
    </div>
  );
}

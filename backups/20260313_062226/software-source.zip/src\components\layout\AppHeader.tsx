"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { signOut, useSession } from "next-auth/react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Bell,
  CheckCheck,
  Copy,
  KeyRound,
  Loader2,
  LogOut,
  Search,
  Settings,
  ShieldCheck,
  ShieldOff,
  User,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import type { AppBrandingDetail } from "@/components/layout/SystemThemeBootstrap";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import {
  BRANDING_UPDATED_EVENT,
  DEFAULT_APP_NAME,
  DEFAULT_APP_TAGLINE,
  RUNTIME_SETTINGS_STORAGE_KEY,
  resolveBranding,
} from "@/lib/branding";

type HeaderNotification = {
  id: string;
  type: string;
  title: string;
  body: string | null;
  link: string | null;
  isRead: boolean;
  createdAt: string;
};

type SelfTwoFactorState = {
  enabled: boolean;
  backupCodesRemaining: number;
  updatedAt: string | null;
};

function formatRelative(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const diffMs = Date.now() - date.getTime();
  const mins = Math.max(1, Math.floor(diffMs / 60000));
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d`;
  return date.toLocaleDateString();
}

export function AppHeader() {
  const { data: session } = useSession();
  const router = useRouter();
  const user = session?.user;
  const [appName, setAppName] = useState(DEFAULT_APP_NAME);
  const [appTagline, setAppTagline] = useState(DEFAULT_APP_TAGLINE);
  const [notifications, setNotifications] = useState<HeaderNotification[]>([]);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notificationsLoading, setNotificationsLoading] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notificationsError, setNotificationsError] = useState<string | null>(null);
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changePasswordError, setChangePasswordError] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);
  const [twoFactorOpen, setTwoFactorOpen] = useState(false);
  const [twoFactorLoading, setTwoFactorLoading] = useState(false);
  const [twoFactorSaving, setTwoFactorSaving] = useState(false);
  const [twoFactorError, setTwoFactorError] = useState("");
  const [twoFactorState, setTwoFactorState] = useState<SelfTwoFactorState | null>(null);
  const [twoFactorSetup, setTwoFactorSetup] = useState<{
    secret: string;
    otpAuthUri: string;
    backupCodes: string[];
  } | null>(null);
  const notificationsRef = useRef<HTMLDivElement | null>(null);
  const initials = user?.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : "??";

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(RUNTIME_SETTINGS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Record<string, string>;
        const branding = resolveBranding(parsed);
        setAppName(branding.appName);
        setAppTagline(branding.appTagline);
      }
    } catch {
      // no-op
    }

    const handler = (event: Event) => {
      const customEvent = event as CustomEvent<AppBrandingDetail>;
      const detail = customEvent.detail;
      if (!detail) return;
      setAppName(detail.appName || DEFAULT_APP_NAME);
      setAppTagline(detail.appTagline || DEFAULT_APP_TAGLINE);
    };
    window.addEventListener(BRANDING_UPDATED_EVENT, handler);
    return () => {
      window.removeEventListener(BRANDING_UPDATED_EVENT, handler);
    };
  }, []);

  const fetchNotifications = useCallback(async (opts?: { silent?: boolean }) => {
    if (!opts?.silent) setNotificationsLoading(true);
    setNotificationsError(null);
    try {
      const response = await fetch("/api/notifications?limit=30", { cache: "no-store" });
      if (!response.ok) throw new Error("Failed to load notifications");
      const payload = (await response.json()) as {
        notifications?: HeaderNotification[];
        unreadCount?: number;
      };
      setNotifications(Array.isArray(payload.notifications) ? payload.notifications : []);
      setUnreadCount(typeof payload.unreadCount === "number" ? payload.unreadCount : 0);
    } catch (error) {
      setNotificationsError(error instanceof Error ? error.message : "Failed to load notifications");
    } finally {
      if (!opts?.silent) setNotificationsLoading(false);
    }
  }, []);

  const markNotificationRead = useCallback(async (id: string) => {
    try {
      const response = await fetch("/api/notifications", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (!response.ok) return;
      setNotifications((prev) => prev.map((item) => (item.id === id ? { ...item, isRead: true } : item)));
      setUnreadCount((prev) => Math.max(0, prev - 1));
    } catch {
      // no-op
    }
  }, []);

  const markAllNotificationsRead = useCallback(async () => {
    try {
      const response = await fetch("/api/notifications", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ all: true }),
      });
      if (!response.ok) return;
      setNotifications((prev) => prev.map((item) => ({ ...item, isRead: true })));
      setUnreadCount(0);
    } catch {
      // no-op
    }
  }, []);

  useEffect(() => {
    if (!session?.user?.id) return;
    void fetchNotifications();
    const intervalId = window.setInterval(() => {
      void fetchNotifications({ silent: true });
    }, 5000);
    return () => {
      window.clearInterval(intervalId);
    };
  }, [fetchNotifications, session?.user?.id]);

  useEffect(() => {
    const onVisibility = () => {
      if (!document.hidden) void fetchNotifications({ silent: true });
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [fetchNotifications]);

  useEffect(() => {
    if (!notificationsOpen) return;
    const onPointerDown = (event: PointerEvent) => {
      const target = event.target as Node;
      if (notificationsRef.current?.contains(target)) return;
      setNotificationsOpen(false);
    };
    document.addEventListener("pointerdown", onPointerDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
    };
  }, [notificationsOpen]);

  const notificationTitle = useMemo(() => {
    if (unreadCount === 0) return "No unread notifications";
    if (unreadCount === 1) return "1 unread notification";
    return `${unreadCount} unread notifications`;
  }, [unreadCount]);

  const loadTwoFactorState = useCallback(async () => {
    setTwoFactorLoading(true);
    setTwoFactorError("");
    try {
      const response = await fetch("/api/account/2fa", { cache: "no-store" });
      const data = (await response.json().catch(() => ({}))) as {
        error?: string;
        enabled?: boolean;
        backupCodesRemaining?: number;
        updatedAt?: string | null;
      };
      if (!response.ok) {
        setTwoFactorError(data.error || "Failed to load 2-step settings.");
        return;
      }
      setTwoFactorState({
        enabled: Boolean(data.enabled),
        backupCodesRemaining: Number(data.backupCodesRemaining ?? 0),
        updatedAt: data.updatedAt ?? null,
      });
    } catch {
      setTwoFactorError("Failed to load 2-step settings.");
    } finally {
      setTwoFactorLoading(false);
    }
  }, []);

  const openTwoFactorDialog = useCallback(() => {
    setTwoFactorOpen(true);
    setTwoFactorError("");
    setTwoFactorSetup(null);
    void loadTwoFactorState();
  }, [loadTwoFactorState]);

  const onTwoFactorAction = useCallback(
    async (action: "enable" | "disable") => {
      setTwoFactorSaving(true);
      setTwoFactorError("");
      try {
        const response = await fetch("/api/account/2fa", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action }),
        });
        const data = (await response.json().catch(() => ({}))) as {
          error?: string;
          enabled?: boolean;
          backupCodesRemaining?: number;
          updatedAt?: string | null;
          secret?: string;
          otpAuthUri?: string;
          backupCodes?: string[];
        };
        if (!response.ok) {
          setTwoFactorError(data.error || "Failed to update 2-step verification.");
          return;
        }

        setTwoFactorState({
          enabled: Boolean(data.enabled),
          backupCodesRemaining: Number(data.backupCodesRemaining ?? data.backupCodes?.length ?? 0),
          updatedAt: data.updatedAt ?? new Date().toISOString(),
        });

        if (action === "enable") {
          setTwoFactorSetup({
            secret: data.secret ?? "",
            otpAuthUri: data.otpAuthUri ?? "",
            backupCodes: Array.isArray(data.backupCodes) ? data.backupCodes : [],
          });
          toast.success("2-step verification enabled.");
        } else {
          setTwoFactorSetup(null);
          toast.success("2-step verification disabled.");
        }
      } catch {
        setTwoFactorError("Failed to update 2-step verification.");
      } finally {
        setTwoFactorSaving(false);
      }
    },
    []
  );

  const copyTwoFactorValue = useCallback(async (value: string, label: string) => {
    if (!value) return;
    try {
      await navigator.clipboard.writeText(value);
      toast.success(`${label} copied`);
    } catch {
      toast.error(`Unable to copy ${label.toLowerCase()}`);
    }
  }, []);

  const openChangePasswordDialog = useCallback(() => {
    setChangePasswordError("");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setChangePasswordOpen(true);
  }, []);

  const onSubmitChangePassword = useCallback(async () => {
    setChangePasswordError("");

    if (!currentPassword.trim() || !newPassword.trim() || !confirmPassword.trim()) {
      setChangePasswordError("All fields are required.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setChangePasswordError("New password and confirm password do not match.");
      return;
    }

    try {
      setChangingPassword(true);
      const response = await fetch("/api/account/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword,
          newPassword,
          confirmPassword,
        }),
      });
      const data = (await response.json().catch(() => ({}))) as { error?: string };
      if (!response.ok) {
        setChangePasswordError(data.error || "Failed to change password.");
        return;
      }
      setChangePasswordOpen(false);
      toast.success("Password changed successfully.");
    } catch {
      setChangePasswordError("Failed to change password.");
    } finally {
      setChangingPassword(false);
    }
  }, [confirmPassword, currentPassword, newPassword]);

  return (
    <>
      <header className="relative flex h-16 items-center gap-4 overflow-hidden border-b border-[#6e0e15] bg-[linear-gradient(115deg,var(--twx-topbar-from,#670b11)_0%,var(--twx-topbar-mid,#8e0c14)_35%,var(--twx-topbar-to,#bf101a)_62%,var(--twx-topbar-accent,#FE0000)_100%)] bg-[length:220%_220%] px-4 shadow-[0_12px_28px_-18px_rgba(52,7,9,0.92)] animate-topbar-flow">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_-30%,rgba(255,255,255,0.34),transparent_43%),radial-gradient(circle_at_86%_130%,rgba(255,255,255,0.18),transparent_46%)]" />

      <div className="relative flex w-[220px] shrink-0 items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/30 bg-white/15 text-xs font-bold text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.35)]">
          TW
        </div>
        <div className="min-w-0 leading-tight">
          <span className="app-topbar-title block truncate text-base font-semibold tracking-wide text-white">
            {appName}
          </span>
          <span className="block text-[11px] text-white/70">
            {appTagline}
          </span>
        </div>
      </div>

      {/* Search */}
      <div className="relative flex-1 max-w-xl">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/70" />
          <Input
            placeholder="Search..."
            className="h-10 rounded-xl border-white/25 bg-white/12 pl-9 pr-3 text-sm text-white placeholder:text-white/70 shadow-[inset_0_1px_0_rgba(255,255,255,0.18)] backdrop-blur-md transition-colors focus-visible:border-white/45 focus-visible:bg-white/16 focus-visible:ring-white/35"
          />
        </div>
      </div>

      <div className="relative ml-auto flex items-center gap-2" ref={notificationsRef}>
        <Button
          variant="ghost"
          size="icon"
          title={notificationTitle}
          onClick={() => {
            setNotificationsOpen((prev) => !prev);
            if (!notificationsOpen) void fetchNotifications();
          }}
          className="relative h-9 w-9 rounded-xl border border-white/16 bg-white/10 text-white/85 backdrop-blur-sm transition-all duration-200 hover:-translate-y-[1px] hover:border-white/32 hover:bg-white/18 hover:text-white"
        >
          <Bell className="h-4 w-4" />
          {unreadCount > 0 ? (
            <span className="absolute -right-1 -top-1 inline-flex min-h-5 min-w-5 items-center justify-center rounded-full border border-[#920d14] bg-[#ffd3d6] px-1 text-[10px] font-semibold text-[#860d13]">
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          ) : null}
        </Button>

        {notificationsOpen ? (
          <div className="absolute right-0 top-11 z-50 w-[360px] overflow-hidden rounded-2xl border border-[#f0c9cc] bg-white shadow-[0_28px_65px_-24px_rgba(77,9,14,0.58)]">
            <div className="flex items-center justify-between border-b border-[#f4dadd] bg-[linear-gradient(120deg,#fff9fa,#fff2f3)] px-3 py-2.5">
              <div>
                <p className="text-sm font-semibold text-[#780d13]">Notifications</p>
                <p className="text-xs text-[#a34a50]">{notificationTitle}</p>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className="h-8 gap-1.5 px-2 text-xs text-[#9f131a] hover:bg-[#ffeef0]"
                onClick={() => void markAllNotificationsRead()}
              >
                <CheckCheck className="h-3.5 w-3.5" />
                Mark all read
              </Button>
            </div>

            <div className="max-h-[360px] overflow-y-auto">
              {notificationsLoading ? (
                <div className="flex items-center justify-center gap-2 px-4 py-8 text-sm text-slate-500">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading notifications...
                </div>
              ) : null}

              {!notificationsLoading && notificationsError ? (
                <div className="px-4 py-6 text-sm text-red-600">{notificationsError}</div>
              ) : null}

              {!notificationsLoading && !notificationsError && notifications.length === 0 ? (
                <div className="px-4 py-8 text-center text-sm text-slate-500">No notifications available.</div>
              ) : null}

              {!notificationsLoading && !notificationsError
                ? notifications.map((item) => (
                    <button
                      key={item.id}
                      className={cn(
                        "w-full border-b border-[#f6e3e5] px-4 py-3 text-left transition-colors hover:bg-[#fff8f9]",
                        !item.isRead && "bg-[#fff4f5]"
                      )}
                      onClick={async () => {
                        await markNotificationRead(item.id);
                        setNotificationsOpen(false);
                        if (item.link) router.push(item.link);
                      }}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <p className={cn("text-sm", !item.isRead ? "font-semibold text-[#8f1218]" : "font-medium text-slate-700")}>
                          {item.title}
                        </p>
                        <span className="shrink-0 text-[11px] text-slate-400">{formatRelative(item.createdAt)}</span>
                      </div>
                      {item.body ? <p className="mt-1 text-xs text-slate-500">{item.body}</p> : null}
                    </button>
                  ))
                : null}
            </div>
          </div>
        ) : null}

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger className="group flex cursor-pointer items-center gap-2 rounded-xl border border-white/16 bg-white/10 px-2.5 py-1.5 outline-none shadow-[inset_0_1px_0_rgba(255,255,255,0.18)] backdrop-blur-sm transition-all duration-200 hover:-translate-y-[1px] hover:border-white/30 hover:bg-white/18">
            <Avatar className="h-8 w-8 ring-1 ring-white/35">
              <AvatarImage src={user?.photoUrl ?? undefined} />
              <AvatarFallback className="bg-[linear-gradient(145deg,#fff8f8,#ffdadd)] text-xs font-semibold text-[#b31118]">
                {initials}
              </AvatarFallback>
            </Avatar>
            <span className="hidden max-w-[140px] truncate text-sm font-medium text-white sm:block">
              {user?.name}
            </span>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52 rounded-xl border border-[#f2c6c9] shadow-[0_18px_42px_-24px_rgba(80,12,17,0.55)]">
            <DropdownMenuItem onClick={() => router.push("/profile")}>
              <User className="h-4 w-4" />
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => router.push("/administration")}>
              <Settings className="h-4 w-4" />
              Administration
            </DropdownMenuItem>
            <DropdownMenuItem onClick={openChangePasswordDialog}>
              <KeyRound className="h-4 w-4" />
              Change Password
            </DropdownMenuItem>
            <DropdownMenuItem onClick={openTwoFactorDialog}>
              <ShieldCheck className="h-4 w-4" />
              2-Step Verification
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              variant="destructive"
              className="cursor-pointer"
              onClick={() => signOut({ callbackUrl: "/login" })}
            >
              <LogOut className="h-4 w-4" />
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      </header>

      <Dialog open={changePasswordOpen} onOpenChange={(next) => (!changingPassword ? setChangePasswordOpen(next) : null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Change Password</DialogTitle>
            <DialogDescription>Enter current password, then set a new password.</DialogDescription>
          </DialogHeader>

          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              void onSubmitChangePassword();
            }}
          >
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700" htmlFor="currentPassword">
                Current Password
              </label>
              <Input
                id="currentPassword"
                type="password"
                value={currentPassword}
                onChange={(event) => setCurrentPassword(event.target.value)}
                disabled={changingPassword}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700" htmlFor="newPassword">
                New Password
              </label>
              <Input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(event) => setNewPassword(event.target.value)}
                disabled={changingPassword}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700" htmlFor="confirmPassword">
                Confirm New Password
              </label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                disabled={changingPassword}
              />
            </div>

            {changePasswordError ? <p className="text-sm text-red-600">{changePasswordError}</p> : null}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                disabled={changingPassword}
                onClick={() => setChangePasswordOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={changingPassword} className="bg-[#FE0000] text-white hover:bg-[#d90000]">
                {changingPassword ? (
                  <>
                    <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Password"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={twoFactorOpen}
        onOpenChange={(next) => (!twoFactorSaving ? setTwoFactorOpen(next) : null)}
      >
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>2-Step Verification</DialogTitle>
            <DialogDescription>Enable or disable 2-step verification for your own account.</DialogDescription>
          </DialogHeader>

          {twoFactorLoading ? (
            <div className="flex items-center gap-2 rounded-md border px-3 py-2 text-sm text-slate-600">
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading security settings...
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-3 py-2">
                <div>
                  <p className="text-sm font-medium text-slate-800">
                    Status: {twoFactorState?.enabled ? "Enabled" : "Disabled"}
                  </p>
                  <p className="text-xs text-slate-500">
                    Backup codes left: {twoFactorState?.backupCodesRemaining ?? 0}
                  </p>
                </div>
                {twoFactorState?.enabled ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-1 text-xs font-medium text-emerald-700">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    Protected
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-1 text-xs font-medium text-amber-700">
                    <ShieldOff className="h-3.5 w-3.5" />
                    Not protected
                  </span>
                )}
              </div>

              {twoFactorError ? <p className="text-sm text-red-600">{twoFactorError}</p> : null}

              {twoFactorSetup ? (
                <div className="space-y-3 rounded-lg border border-[#f1d2d4] bg-[#fff8f8] p-3">
                  <p className="text-sm font-medium text-[#8f1218]">Setup details</p>
                  {twoFactorSetup.otpAuthUri ? (
                    <div className="flex flex-col items-center gap-2">
                      <img
                        alt="2-step QR code"
                        className="h-36 w-36 rounded-md border border-slate-200 bg-white p-1"
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(twoFactorSetup.otpAuthUri)}`}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => void copyTwoFactorValue(twoFactorSetup.otpAuthUri, "OTP URI")}
                      >
                        <Copy className="mr-1.5 h-3.5 w-3.5" />
                        Copy OTP URI
                      </Button>
                    </div>
                  ) : null}

                  <div className="rounded-md border bg-white px-3 py-2">
                    <p className="text-xs text-slate-500">Secret key</p>
                    <div className="mt-1 flex items-center justify-between gap-2">
                      <p className="break-all text-sm font-mono text-slate-700">{twoFactorSetup.secret || "Not available"}</p>
                      {twoFactorSetup.secret ? (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => void copyTwoFactorValue(twoFactorSetup.secret, "Secret key")}
                        >
                          <Copy className="mr-1.5 h-3.5 w-3.5" />
                          Copy
                        </Button>
                      ) : null}
                    </div>
                  </div>

                  {twoFactorSetup.backupCodes.length > 0 ? (
                    <div className="rounded-md border bg-white px-3 py-2">
                      <p className="text-xs text-slate-500">Backup codes</p>
                      <div className="mt-2 grid grid-cols-2 gap-2">
                        {twoFactorSetup.backupCodes.map((code) => (
                          <code key={code} className="rounded bg-slate-100 px-2 py-1 text-xs text-slate-700">
                            {code}
                          </code>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              ) : null}
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setTwoFactorOpen(false)} disabled={twoFactorSaving}>
              Close
            </Button>
            {twoFactorState?.enabled ? (
              <Button
                type="button"
                variant="destructive"
                disabled={twoFactorSaving || twoFactorLoading}
                onClick={() => void onTwoFactorAction("disable")}
              >
                {twoFactorSaving ? (
                  <>
                    <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Disable 2-Step"
                )}
              </Button>
            ) : (
              <Button
                type="button"
                className="bg-[#FE0000] text-white hover:bg-[#d90000]"
                disabled={twoFactorSaving || twoFactorLoading}
                onClick={() => void onTwoFactorAction("enable")}
              >
                {twoFactorSaving ? (
                  <>
                    <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                    Enabling...
                  </>
                ) : (
                  "Enable 2-Step"
                )}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

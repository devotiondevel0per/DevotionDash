import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { buildUserAccess } from "@/lib/rbac";

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const access = await buildUserAccess(session.user.id);
    if (!access) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    return NextResponse.json(access);
  } catch (error) {
    console.error("[GET /api/permissions]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}


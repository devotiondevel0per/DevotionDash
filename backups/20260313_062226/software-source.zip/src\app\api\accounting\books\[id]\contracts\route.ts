import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const contracts = await prisma.accountingContract.findMany({
      where: { bookId: id },
      include: { transactions: { orderBy: { date: "desc" } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(contracts);
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const body = await req.json();
    const contract = await prisma.accountingContract.create({
      data: {
        bookId: id,
        number: body.number,
        description: body.description,
        amount: body.amount,
        currency: body.currency ?? "USD",
        status: body.status ?? "active",
        signedAt: body.signedAt ? new Date(body.signedAt) : null,
      },
    });
    return NextResponse.json(contract, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

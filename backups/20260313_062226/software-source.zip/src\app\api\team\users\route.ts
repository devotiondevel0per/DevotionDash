﻿import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireModuleAccess } from "@/lib/api-access";

export async function GET(req: NextRequest) {
  const accessResult = await requireModuleAccess("team", "read");
  if (!accessResult.ok) return accessResult.response;

  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search");
    const isActiveParam = searchParams.get("isActive");
    const parsedLimit = Number.parseInt(searchParams.get("limit") ?? "200", 10);
    const limit = Number.isFinite(parsedLimit)
      ? Math.min(Math.max(parsedLimit, 1), 500)
      : 200;

    const where: Record<string, unknown> = {};
    if (isActiveParam === "true") where.isActive = true;
    if (isActiveParam === "false") where.isActive = false;
    if (search) {
      where.OR = [
        { fullname: { contains: search } },
        { name: { contains: search } },
        { surname: { contains: search } },
        { email: { contains: search } },
        { login: { contains: search } },
        { position: { contains: search } },
        { department: { contains: search } },
      ];
    }

    const users = await prisma.user.findMany({
      where,
      orderBy: { name: "asc" },
      take: limit,
      select: {
        id: true,
        login: true,
        email: true,
        name: true,
        surname: true,
        fullname: true,
        position: true,
        department: true,
        phoneWork: true,
        phoneMobile: true,
        photoUrl: true,
        workState: true,
        isActive: true,
        lastActivity: true,
        dateBirthday: true,
        createdAt: true,
      },
    });

    return NextResponse.json(users);
  } catch (error) {
    console.error("[GET /api/team/users]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}


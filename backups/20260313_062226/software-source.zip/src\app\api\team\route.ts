import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search") ?? undefined;
  const department = searchParams.get("department") ?? undefined;
  try {
    const users = await prisma.user.findMany({
      where: {
        isActive: true,
        ...(department && { department }),
        ...(search && {
          OR: [
            { name: { contains: search } },
            { surname: { contains: search } },
            { fullname: { contains: search } },
            { email: { contains: search } },
            { position: { contains: search } },
          ],
        }),
      },
      select: {
        id: true,
        name: true,
        surname: true,
        fullname: true,
        email: true,
        position: true,
        department: true,
        photoUrl: true,
        phoneWork: true,
        phoneMobile: true,
        dateBirthday: true,
        lastActivity: true,
        workState: true,
        isAdmin: true,
      },
      orderBy: [{ department: "asc" }, { name: "asc" }],
    });
    return NextResponse.json(users);
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

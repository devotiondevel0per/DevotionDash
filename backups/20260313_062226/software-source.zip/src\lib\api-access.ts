import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { assertModuleAccess, buildUserAccess, type UserAccess } from "@/lib/rbac";
import { type ModuleId, type PermissionAction } from "@/lib/permissions";

export interface AccessContext {
  userId: string;
  access: UserAccess;
}

export async function requireModuleAccess(
  moduleId: ModuleId,
  action: PermissionAction = "read"
): Promise<{ ok: true; ctx: AccessContext } | { ok: false; response: NextResponse }> {
  const session = await auth();
  if (!session?.user?.id) {
    return {
      ok: false,
      response: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  const access = await buildUserAccess(session.user.id);
  if (!access) {
    return {
      ok: false,
      response: NextResponse.json({ error: "Unauthorized" }, { status: 401 }),
    };
  }

  if (!assertModuleAccess(access, moduleId, action)) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: `Forbidden: missing ${moduleId}.${action} permission` },
        { status: 403 }
      ),
    };
  }

  return { ok: true, ctx: { userId: session.user.id, access } };
}


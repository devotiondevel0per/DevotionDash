import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { buildUserAccess } from "@/lib/rbac";
import { canAccessNotificationLink } from "@/lib/notification-access";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const unreadOnly = searchParams.get("unreadOnly") === "true";
  const parsedLimit = Number.parseInt(searchParams.get("limit") ?? "20", 10);
  const limit = Number.isFinite(parsedLimit) ? Math.min(Math.max(parsedLimit, 1), 100) : 20;
  try {
    const access = await buildUserAccess(session.user!.id!);
    if (!access) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const rows = await prisma.notification.findMany({
      where: { userId: session.user!.id! },
      orderBy: { createdAt: "desc" },
      take: 300,
    });

    const visible = rows.filter((item) =>
      canAccessNotificationLink(item.link, access.accessibleModules)
    );
    const unreadCount = visible.filter((item) => !item.isRead).length;
    const notifications = (unreadOnly ? visible.filter((item) => !item.isRead) : visible).slice(0, limit);

    return NextResponse.json({
      notifications,
      unreadCount,
      serverTime: new Date().toISOString(),
    });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  const session = await auth();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const { all, id } = await req.json() as { all?: boolean; id?: string };
    if (all) {
      await prisma.notification.updateMany({ where: { userId: session.user!.id! }, data: { isRead: true } });
    } else if (id) {
      await prisma.notification.updateMany({
        where: { id, userId: session.user!.id! },
        data: { isRead: true },
      });
    }
    const unreadCount = await prisma.notification.count({
      where: { userId: session.user!.id!, isRead: false },
    });
    return NextResponse.json({ ok: true, unreadCount });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
